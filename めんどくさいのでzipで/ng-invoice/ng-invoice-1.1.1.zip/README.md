# NG-Invoice System

## 概要
NG-Invoice System は、FiveM の QBCore/QBX フレームワーク用の請求書システムです。プレイヤーや企業が他のプレイヤーに請求書を発行し、支払いを管理できる包括的なソリューションを提供します。

## 特徴
- 複数の受信者に一度に請求書を発行
- ジョブごとのプリセット請求項目
- 割引率の適用機能
- 個人請求と企業請求の選択
- 複数の請求書の一括支払い
- ボス権限を持つプレイヤー向けの管理機能
- 請求書の強制執行機能 (特定のジョブのみ)
- 詳細な Discord Webhook 通知

## 依存関係
- [qb-core](https://github.com/qbcore-framework/qb-core) または [qbx-core](https://github.com/Qbox-project/qbx-core)
- [ox_lib](https://github.com/overextended/ox_lib)
- [oxmysql](https://github.com/overextended/oxmysql)

## インストール方法
1. このリポジトリをダウンロードします
2. リソースフォルダを `ng-invoice` という名前で FiveM サーバーの `resources` フォルダに配置します
3. `server.cfg` に以下の行を追加します:
```
ensure ng-invoice
```
4. サーバーを再起動または `refresh` コマンドを実行し、`ensure ng-invoice` を実行します

## 設定方法
`shared/config.lua` ファイルで以下の設定をカスタマイズできます:

### 基本設定
- `Config.Webhook` - Discord通知用のWebhook URL (無効にする場合は `false`)
- `Config.OpenKey` - UIを開くキー (デフォルト: 'F7')
- `Config.AdminGroup` - 管理者権限グループ (デフォルト: 'group.admin')
- `Config.QBType` - 使用しているQBCoreのタイプ ('qb' または 'qbx')

### バンキングシステム設定
- `Config.BankingSystem` - 使用しているバンキングシステム
  - 'renewed' : Renewed-Banking
  - 'qb' : QB-Banking
  - 'okok' : okokBanking
  - 'qb-management' : qb-management

### 強制執行設定
- `Config.ForcePaymentJobs` - 請求書の強制執行が可能なジョブのリスト
- `Config.ForcePayment.allowNegativeBalance` - 残高がマイナスになることを許可するかどうか
- `Config.ForcePayment.checkAccounts` - 残高チェック対象の口座タイプ

### ジョブ設定
- `Config.JobList` - プリセット請求を使用できるジョブのリスト
- `Config.JobPaymentRatio` - ジョブごとの収入分配率設定 (%)
- `Config.JobInvoicePresets` - ジョブごとの請求内容プリセット

### メッセージ設定
- `Config.Messages` - システム内で使用される各種メッセージ

## 使用方法

### プレイヤー向け
1. `F7` キー (デフォルト) を押して請求書メニューを開きます
2. 以下の機能を利用できます:
   - 請求書作成: 近くのプレイヤーに請求書を発行
   - 請求書支払い: 受け取った請求書の確認と支払い

### 請求書作成
1. メニューから「請求書作成」を選択
2. 請求書名を入力
3. ジョブに応じたプリセット項目から選択するか、その他の金額を入力
4. 割引率を設定 (オプション)
5. 個人請求にするかどうかを選択 (ジョブで請求時のみ)
6. 請求先のプレイヤーを選択 (複数選択可能)

### 請求書支払い
1. メニューから「請求書支払い」を選択
2. 未払いの請求書一覧が表示されます
3. 個別に支払うか、まとめて支払いを選択
4. 支払い方法 (現金または銀行) を選択

### ボス向け機能
ジョブのボス権限を持つプレイヤーは、以下の追加機能を利用できます:
- 請求書リスト (ボス): ジョブに関連する全ての請求書を表示
- 請求書の削除: 不要な請求書を削除
- 強制執行 (特定のジョブのみ): 請求書の支払いを強制的に実行

## ジョブごとの請求書設定
各ジョブのプリセット請求項目と収入分配率は `config.lua` で設定できます。例:

```lua
Config.JobInvoicePresets = {
    ['police'] = {
        {label = '武器ライセンス発行手数料', amount = 300000},
        {label = '道路交通法違反', amount = 300000},
        -- 他の項目...
    },
    ['mechanic'] = {
        {label = '修理', amount = 200000},
        {label = '出張修理', amount = 600000},
    },
    -- 他のジョブ...
}

Config.JobPaymentRatio = {
    ['police'] = 50,     -- 50%が職業口座、50%が個人の手持ち
    ['mechanic'] = 70,   -- 70%が職業口座、30%が個人の手持ち
    -- 他のジョブ...
}
```

## Discord Webhook 通知
Webhook URLを設定すると、以下のイベント時に通知が送信されます:
- 請求書作成時
- 請求書支払い時
- 請求書強制執行時

## 技術的な詳細
- データベースは自動的に初期化されます
- 請求書のステータスは 'pending'(未払い), 'paid'(支払済), 'cancelled'(キャンセル) の3種類
- ボス権限は QBCore/QBX の設定に基づいて自動的に判定されます

## トラブルシューティング
- 請求書メニューが表示されない場合:
  - ox_lib が正しくインストールされているか確認
  - キーバインドが他のリソースと競合していないか確認
- 支払いが失敗する場合:
  - 十分な残高があるか確認
  - データベース接続が正常か確認
- ボス機能にアクセスできない場合:
  - ジョブの grade 設定で `isboss = true` が正しく設定されているか確認

## クレジット
作成者: NCCGr

## ライセンス
このリソースは、特に明示されていない限り、著作権所有者の許可なく再配布や改変を禁止します。