local QBCore = exports['qb-core']:GetCoreObject()
local isAdmin = false

-- 権限チェック
RegisterNetEvent('ng-invoice:client:permissionResponse', function(hasPermission)
    isAdmin = hasPermission
end)

-- 請求書作成メニュー
local function OpenCreateInvoiceMenu()
    -- 近くのプレイヤーを取得
    local playerPed = PlayerPedId()
    local players = GetActivePlayers()
    local nearbyPlayers = {}

    for _, player in ipairs(players) do
        local targetPed = GetPlayerPed(player)
        local targetCoords = GetEntityCoords(targetPed)
        local distance = #(GetEntityCoords(playerPed) - targetCoords)
        
        if distance <= 3.0 and player ~= PlayerId() then
            local targetId = GetPlayerServerId(player)
            local playerData = lib.callback.await('ng-invoice:getPlayerData', false, targetId)
            if playerData then
                table.insert(nearbyPlayers, {
                    label = string.format("%s [%s] [%s]", 
                        playerData.firstname .. " " .. playerData.lastname,
                        targetId,
                        playerData.citizenid
                    ),
                    value = playerData.citizenid
                })
            end
        end
    end

    if #nearbyPlayers == 0 then
        QBCore.Functions.Notify('近くにプレイヤーがいません', 'error')
        return
    end

    local playerJob = QBCore.Functions.GetPlayerData().job.name
    local hasJobAccess = Config.JobList[playerJob] or false
    local inputElements = {
        {
            type = 'input',
            label = '請求書名',
            placeholder = '請求書の名前を入力してください',
            required = true
        }
    }

    -- プリセット選択肢の作成（対象職業のみ）
    if hasJobAccess and Config.JobInvoicePresets[playerJob] then
        local presetOptions = {}
        for _, preset in ipairs(Config.JobInvoicePresets[playerJob]) do
            table.insert(presetOptions, {
                label = string.format("%s ($%s)", preset.label, preset.amount),
                value = preset.label,
                description = preset.amount
            })
        end
        
        table.insert(inputElements, {
            type = 'multi-select',
            label = '請求内容',
            options = presetOptions
        })
    end

    -- 割引入力フィールドを追加
    table.insert(inputElements, {
        type = 'number',
        label = '割引率 (%)',
        description = '0-100までの割引率を入力してください',
        default = 0,
        min = 0,
        max = 100
    })

    -- その他の金額入力フィールド（すべての職業で使用可能）
    table.insert(inputElements, {
        type = 'number',
        label = 'その他の金額',
        description = '請求金額を入力してください',
        default = 0,
        min = 0
    })

    -- プリセット職業の場合のみ個人請求オプションを表示
    if hasJobAccess then
        table.insert(inputElements, {
            type = 'checkbox',
            label = '個人請求',
            description = 'チェックを入れると全額が個人の手持ちになります'
        })
    end

    table.insert(inputElements, {
        type = 'select',
        label = '請求先',
        options = nearbyPlayers,
        required = true
    })

    local input = lib.inputDialog('請求書作成', inputElements)
    if not input then return end

    local totalAmount = 0
    local selectedContents = {}
    local contentIndex = 2
    local discountIndex = hasJobAccess and (Config.JobInvoicePresets[playerJob] and 3 or 2) or 2
    local otherAmountIndex = hasJobAccess and (Config.JobInvoicePresets[playerJob] and 4 or 3) or 3
    local recipientIndex = hasJobAccess and (Config.JobInvoicePresets[playerJob] and 6 or 5) or 4

    -- プリセットがある職業の場合の金額計算
    if hasJobAccess and Config.JobInvoicePresets[playerJob] then
        if input[contentIndex] then
            for _, selectedLabel in ipairs(input[contentIndex]) do
                for _, preset in ipairs(Config.JobInvoicePresets[playerJob]) do
                    if preset.label == selectedLabel then
                        totalAmount = totalAmount + preset.amount
                        table.insert(selectedContents, string.format("%s: $%s", preset.label, preset.amount))
                        break
                    end
                end
            end
        end
    end

    -- その他の金額の処理
    if input[otherAmountIndex] and input[otherAmountIndex] > 0 then
        totalAmount = totalAmount + input[otherAmountIndex]
        table.insert(selectedContents, string.format("その他: $%s", input[otherAmountIndex]))
    end

    -- 割引の適用
    local discountRate = input[discountIndex] or 0
    if discountRate > 0 then
        local discountAmount = math.floor(totalAmount * (discountRate / 100))
        totalAmount = totalAmount - discountAmount
        table.insert(selectedContents, string.format("割引 (%s%%): -$%s", discountRate, discountAmount))
    end

    -- 金額チェック
    if totalAmount == 0 then
        QBCore.Functions.Notify('金額を入力してください', 'error')
        return
    end

    -- 個人請求フラグ（プリセット職業の場合のみ）
    local isPersonal = false
    if hasJobAccess then
        local personalIndex = hasJobAccess and (Config.JobInvoicePresets[playerJob] and 5 or 4) or 4
        isPersonal = input[personalIndex] and true or false
    end

    -- 請求書作成
    local success = lib.callback.await('ng-invoice:createInvoice', false, {
        title = input[1],
        content = #selectedContents > 0 and table.concat(selectedContents, "\n") or string.format("その他: $%s", totalAmount),
        total_amount = totalAmount,
        recipient_citizenid = input[recipientIndex],
        is_personal = isPersonal,
        discount_rate = discountRate
    })

    if success then
        QBCore.Functions.Notify(Config.Messages.invoice_created, 'success')
    else
        QBCore.Functions.Notify('請求書の作成に失敗しました', 'error')
    end
end

-- OpenPaymentMethodMenu関数内の修正
local function OpenPaymentMethodMenu(invoice)
    local contentText = string.format(
        '請求金額: $%s\n%s\n\n支払い方法を選択してください',
        invoice.total_amount,
        invoice.discount_rate > 0 and string.format('(割引率: %s%%適用済み)', invoice.discount_rate) or ''
    )

    local alert = lib.alertDialog({
        header = '支払い方法の選択',
        content = contentText,
        cancel = true,
        labels = {
            confirm = 'キャッシュで支払う',
            cancel = '銀行で支払う'
        }
    })

    if alert then
        local paymentType = alert == 'confirm' and 'cash' or 'bank'
        local success = lib.callback.await('ng-invoice:payInvoice', false, invoice.id, paymentType)
        if success then
            QBCore.Functions.Notify(Config.Messages.invoice_paid, 'success')
            OpenPaymentMenu() -- メニューを更新
        end
    end
end

-- 支払いメニュー
local function OpenPaymentMenu()
    print('Opening payment menu...') -- デバッグログ
    
    local invoices = lib.callback.await('ng-invoice:getInvoices', false, 'received')
    print('Received invoices:', json.encode(invoices)) -- デバッグログ
    
    if not invoices then 
        print('No invoices received') -- デバッグログ
        QBCore.Functions.Notify('未払いの請求書はありません', 'info')
        return 
    end

    local options = {}
    for _, invoice in ipairs(invoices) do
        if invoice.status == 'pending' then
            print('Processing pending invoice:', json.encode(invoice)) -- デバッグログ
            table.insert(options, {
                title = string.format("%s [%s]", invoice.sender_name or "不明", invoice.sender_citizenid),
                description = string.format('職業: %s\n%s\n合計金額: $%s',
                    invoice.sender_job,
                    invoice.content,
                    invoice.total_amount
                ),
                onSelect = function()
                    local alert = lib.alertDialog({
                        header = '請求書の支払い',
                        content = string.format('請求者: %s [%s]\n職業: %s\n\n請求内容:\n%s\n\n合計金額: $%s\n\n支払い方法を選択しますか？',
                            invoice.sender_name or "不明",
                            invoice.sender_citizenid,
                            invoice.sender_job,
                            invoice.content,
                            invoice.total_amount
                        ),
                        cancel = true,
                        labels = {
                            confirm = '支払う',
                            cancel = 'キャンセル'
                        }
                    })

                    if alert == 'confirm' then
                        OpenPaymentMethodMenu(invoice)
                    end
                end
            })
        end
    end

    print('Created menu options:', #options) -- デバッグログ

    if #options == 0 then
        print('No pending invoices found') -- デバッグログ
        QBCore.Functions.Notify('未払いの請求書はありません', 'info')
        return
    end

    print('Registering context menu') -- デバッグログ
    lib.registerContext({
        id = 'invoice_payment_menu',
        title = '請求書支払い',
        options = options
    })

    print('Showing context menu') -- デバッグログ
    lib.showContext('invoice_payment_menu')
end

-- メインメニュー
local function OpenMainMenu()
    lib.registerContext({
        id = 'invoice_main_menu',
        title = '請求書システム',
        options = {
            {
                title = '請求書作成',
                description = '新しい請求書を作成します',
                icon = 'file',
                onSelect = function()
                    OpenCreateInvoiceMenu()
                end
            },
            {
                title = '請求書支払い',
                description = '受信した請求書の確認と支払い',
                icon = 'money-bill',
                onSelect = function()
                    OpenPaymentMenu()
                end
            }
        }
    })

    lib.showContext('invoice_main_menu')
end

-- キーバインドの登録
RegisterCommand('+openInvoice', function()
    if LocalPlayer.state.dead then return end
    OpenMainMenu()
end, false)

RegisterKeyMapping('+openInvoice', '請求書システムを開く', 'keyboard', Config.OpenKey)

-- 初期化
CreateThread(function()
    TriggerServerEvent('ng-invoice:server:checkPermission')
end)

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    TriggerServerEvent('ng-invoice:server:checkPermission')
end)
