local QBCore = exports['qb-core']:GetCoreObject()
local cooldown = false
local isAiming = false
local aimingCam = nil
local currentCamCoords = vector3(0, 0, 0)
local camMoveSpeed = 5.0

-- エフェクトのロード
CreateThread(function()
    RequestNamedPtfxAsset(Config.Effects.effectLib)
    while not HasNamedPtfxAssetLoaded(Config.Effects.effectLib) do
        Wait(0)
    end
end)

-- 上空カメラの作成
local function CreateAimingCamera()
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)
    
    -- カメラの初期位置を設定
    currentCamCoords = vector3(coords.x, coords.y, coords.z + 200.0)
    
    -- カメラの作成
    aimingCam = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
    SetCamCoord(aimingCam, currentCamCoords.x, currentCamCoords.y, currentCamCoords.z)
    SetCamRot(aimingCam, -90.0, 0.0, 0.0)
    
    -- カメラのレンダリング開始
    SetCamActive(aimingCam, true)
    RenderScriptCams(true, false, 0, true, true)
    
    -- プレイヤーを無敵に
    SetEntityInvincible(playerPed, true)
    SetEntityVisible(playerPed, false)
    FreezeEntityPosition(playerPed, true)
end

-- 上空カメラの削除
local function DestroyAimingCamera()
    -- カメラの削除
    SetCamActive(aimingCam, false)
    DestroyCam(aimingCam, true)
    RenderScriptCams(false, false, 0, true, true)
    aimingCam = nil
    
    -- プレイヤーの状態を戻す
    local playerPed = PlayerPedId()
    SetEntityInvincible(playerPed, false)
    SetEntityVisible(playerPed, true)
    FreezeEntityPosition(playerPed, false)
end

-- カメラの移動
local function UpdateCameraPosition()
    if not aimingCam then return end
    
    -- WASDキーの入力を取得
    local moveX = 0
    local moveY = 0
    
    if IsDisabledControlPressed(0, 32) then moveY = moveY + 1.0 end  -- W
    if IsDisabledControlPressed(0, 33) then moveY = moveY - 1.0 end  -- S
    if IsDisabledControlPressed(0, 34) then moveX = moveX - 1.0 end  -- A
    if IsDisabledControlPressed(0, 35) then moveX = moveX + 1.0 end  -- D
    
    -- カメラ位置の更新
    if moveX ~= 0 or moveY ~= 0 then
        currentCamCoords = vector3(
            currentCamCoords.x + (moveX * camMoveSpeed),
            currentCamCoords.y + (moveY * camMoveSpeed),
            currentCamCoords.z
        )
        SetCamCoord(aimingCam, currentCamCoords.x, currentCamCoords.y, currentCamCoords.z)
    end
end

-- ターゲット座標の取得（上空視点用）
local function GetTargetCoords()
    if not aimingCam then return false, vector3(0, 0, 0) end
    
    -- マウスの位置から照準位置を計算
    local mouseX = GetControlNormal(0, 239) -- CURSOR_X
    local mouseY = GetControlNormal(0, 240) -- CURSOR_Y
    
    -- スクリーン座標をワールド座標に変換
    local targetX = currentCamCoords.x + (mouseX - 0.5) * 100.0
    local targetY = currentCamCoords.y + (mouseY - 0.5) * 100.0
    local targetZ = 0 -- 地面レベル
    
    -- レイキャストで実際の衝突位置を取得
    local ray = StartExpensiveSynchronousShapeTestLosProbe(
        currentCamCoords.x, currentCamCoords.y, currentCamCoords.z,
        targetX, targetY, targetZ,
        1, PlayerPedId(), 4
    )
    
    local _, hit, endCoords = GetShapeTestResult(ray)
    
    if hit == 1 then
        return true, endCoords
    else
        return false, vector3(targetX, targetY, targetZ)
    end
end

-- サテライトキャノンの発射（サーバーと同期）
local function FireSatellite(coords)
    -- サーバーにエフェクト再生を要求
    TriggerServerEvent('ng-satellite:server:fireEffect', coords)
    
    if cooldown then return end
    
    -- クールダウンの開始
    cooldown = true
    local timeLeft = Config.Satellite.cooldown
    
    CreateThread(function()
        while timeLeft > 0 do
            Wait(1000)
            timeLeft = timeLeft - 1
        end
        cooldown = false
    end)
end

-- エフェクトの再生（サーバーからトリガー）
RegisterNetEvent('ng-satellite:client:playEffect')
AddEventHandler('ng-satellite:client:playEffect', function(coords)
    -- エフェクト用の高度設定
    local effectHeight = coords.z + 200.0
    
    -- プレエフェクトの再生
    UseParticleFxAssetNextCall(Config.Effects.effectLib)
    local preEffect = StartParticleFxLoopedAtCoord(
        Config.Effects.preEffect,
        coords.x, coords.y, effectHeight,
        0.0, 0.0, 0.0,
        1.0,
        false, false, false, false
    )

    -- カメラシェイク
    ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', Config.Satellite.shake)

    -- メインエフェクトとダメージの適用
    SetTimeout(2000, function()
        -- プレエフェクトの停止
        StopParticleFxLooped(preEffect, 0)

        -- メインエフェクトの再生
        UseParticleFxAssetNextCall(Config.Effects.effectLib)
        StartParticleFxNonLoopedAtCoord(
            Config.Effects.mainEffect,
            coords.x, coords.y, coords.z,
            0.0, 0.0, 0.0,
            5.0,
            false, false, false
        )

        -- 爆発音の再生
        PlaySoundFromCoord(-1, "DLC_XM_Explosions_Orbital_Cannon", coords.x, coords.y, coords.z, 0, true, 0, false)
        
        -- 爆発の作成
        AddExplosion(
            coords.x, coords.y, coords.z,
            59, -- EXPLOSION_ORBITAL_CANNON
            Config.Satellite.damage,
            true,
            false,
            Config.Satellite.shake
        )
    end)
end)

-- 照準モードの制御
CreateThread(function()
    while true do
        Wait(0)
        if isAiming then
            -- マウスカーソルの表示
            SetMouseCursorActiveThisFrame()
            DisableControlAction(0, 1, true) -- Look Left/Right
            DisableControlAction(0, 2, true) -- Look Up/Down
            
            -- WASD操作を無効化（カメラ移動用）
            DisableControlAction(0, 32, false) -- W
            DisableControlAction(0, 33, false) -- S
            DisableControlAction(0, 34, false) -- A
            DisableControlAction(0, 35, false) -- D
            
            -- カメラの更新
            UpdateCameraPosition()
            
            -- 左クリックで発射
            if IsDisabledControlJustPressed(0, 24) then -- LEFT MOUSE BUTTON
                local success, coords = GetTargetCoords()
                if success then
                    FireSatellite(coords)
                    -- エイム状態を解除
                    isAiming = false
                    DestroyAimingCamera()
                end
            end
            
            -- 右クリックでキャンセル
            if IsDisabledControlJustPressed(0, 25) then -- RIGHT MOUSE BUTTON
                isAiming = false
                DestroyAimingCamera()
            end
        end
    end
end)

-- コマンドの登録
RegisterCommand(Config.Command.name, function()
    -- クールダウンチェック 
    if cooldown then
        local timeLeft = Config.Satellite.cooldown
        lib.notify({
            title = '通知',
            description = string.format(Config.Messages.cooldown, timeLeft),
            type = 'error'
        })
        return
    end
    
    -- 照準モードの開始
    isAiming = true
    CreateAimingCamera()
end, false)

-- コマンドのサジェスト登録
TriggerEvent('chat:addSuggestion', '/' .. Config.Command.name, Config.Command.description)