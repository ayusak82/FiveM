local QBCore = exports['qb-core']:GetCoreObject()
local display = false
local isCivilianMode = false

-- UIの表示/非表示制御
function SetDisplay(bool, civMode)
    display = bool
    isCivilianMode = civMode or false
    SetNuiFocus(bool, bool)
    SendNUIMessage({
        type = "ui",
        status = bool,
        config = Config.UI,
        civilianMode = isCivilianMode
    })
end

-- 警察メニューを開くイベント
RegisterNetEvent('ng-wanted:client:openMenu', function()
    if not Config.AllowedJobs[QBCore.Functions.GetPlayerData().job.name] then
        QBCore.Functions.Notify('警察関係者のみがこの機能を使用できます', 'error')
        return
    end
    
    -- サーバーにいるプレイヤーのリストを取得
    QBCore.Functions.TriggerCallback('ng-wanted:server:getPlayers', function(players)
        -- 指名手配リストを取得してUIに表示
        QBCore.Functions.TriggerCallback('ng-wanted:server:getWantedList', function(wantedList)
            SendNUIMessage({
                type = "init",
                crimesList = Config.Crimes,
                wantedList = wantedList,
                maxWantedTime = Config.MaxWantedTime,
                playersList = players,
                civilianMode = false
            })
            SetDisplay(true, false)
        end)
    end)
end)

-- 一般市民用メニューを開くイベント
RegisterNetEvent('ng-wanted:client:openCivilianMenu', function()
    -- 誰でも閲覧可能
    if not Config.AllowCivilianAccess then
        QBCore.Functions.Notify('この機能は現在利用できません', 'error')
        return
    end
    
    -- 指名手配リストを取得してUIに表示
    QBCore.Functions.TriggerCallback('ng-wanted:server:getWantedList', function(wantedList)
        SendNUIMessage({
            type = "init",
            crimesList = Config.Crimes,
            wantedList = wantedList,
            civilianMode = true
        })
        SetDisplay(true, true)
    end)
end)

-- 指名手配リストを更新するイベント
RegisterNetEvent('ng-wanted:client:refreshWantedList', function()
    if display then
        Citizen.CreateThread(function()
            Citizen.Wait(500) -- 少し待ってからリストを更新
            
            QBCore.Functions.TriggerCallback('ng-wanted:server:getWantedList', function(wantedList)
                SendNUIMessage({
                    type = "refreshList",
                    wantedList = wantedList
                })
            end)
        end)
    end
end)

-- NUIからのコールバック

-- UIを閉じる
RegisterNUICallback('close', function(data, cb)
    SetDisplay(false)
    cb('ok')
end)

-- 指名手配の追加
RegisterNUICallback('addWanted', function(data, cb)
    TriggerServerEvent('ng-wanted:server:addWanted', data)
    cb('ok')
end)

-- 指名手配の削除
RegisterNUICallback('removeWanted', function(data, cb)
    -- 確認なしですぐにサーバーイベントを呼び出す
    TriggerServerEvent('ng-wanted:server:removeWanted', data.id)
    
    -- 即座にOKを返答
    cb('ok')
end)

-- 初期化処理
CreateThread(function()
    -- リソース開始時にUIを閉じておく
    SetDisplay(false)
end)

-- 指名手配通知を受け取るイベント
RegisterNetEvent('ng-wanted:client:notifyWanted', function(message)
    -- 通知音を再生
    if Config.Notification and Config.Notification.enable then
        local soundType = Config.Notification.soundType
        
        if soundType == "native" then
            -- ネイティブサウンド再生
            local soundConfig = Config.Notification.nativeSound
            PlaySoundFrontend(-1, soundConfig.sound, soundConfig.soundSet, true)
            Citizen.Wait(100)
            PlaySoundFrontend(-1, "TIMER_STOP", "HUD_MINI_GAME_SOUNDSET", true)
            Citizen.Wait(100)
            PlaySoundFrontend(-1, soundConfig.sound, soundConfig.soundSet, true)
            
        elseif soundType == "mp3" then
            -- MP3サウンド再生
            local mp3Config = Config.Notification.mp3Sound
            SendNUIMessage({
                type = "playSound",
                sound = mp3Config.file,
                volume = mp3Config.volume
            })
            
        elseif soundType == "qbcore" then
            -- QBCore通知のみ（音なし）
            -- 音はQBCore側で処理される
        end
    end
    
    -- 通知を表示
    if Config.Notification.soundType == "qbcore" then
        -- QBCore純正通知
        local qbConfig = Config.Notification.qbcoreNotification
        QBCore.Functions.Notify(message, qbConfig.type, qbConfig.duration)
    else
        -- 通常通知（表示時間を15秒に延長）
        QBCore.Functions.Notify(message, "警告", 15000)
    end
end)

-- コマンド登録
RegisterCommand('wanted', function()
    TriggerEvent('ng-wanted:client:openMenu')
end, false)

RegisterCommand('wantedlist', function()
    TriggerEvent('ng-wanted:client:openCivilianMenu')
end, false)

-- キーバインド登録
RegisterKeyMapping('wanted', '指名手配システムを開く（警察用）', 'keyboard', '')
RegisterKeyMapping('wantedlist', '指名手配リストを見る（市民用）', 'keyboard', '')
