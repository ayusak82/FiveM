# NG-Wanted - 指名手配システム

QBCore用の指名手配システムスクリプトです。警察関係者が犯罪者を指名手配し、サーバー内の全プレイヤーに通知できるシステムです。

## 機能

- 警察関係者による指名手配の登録/削除
- 複数の犯罪者を同時に選択可能
- 罪名選択による罰金の自動計算（手動調整も可能）
- 全プレイヤーへの指名手配通知（警報音付き）
- 一般市民用の指名手配リスト閲覧機能
- 指定時間経過後の自動削除機能
- **3種類の通知音タイプ対応（Native / MP3 / QBCore）**

## 依存関係

- QB-Core
- ox_lib
- oxmysql

## インストール方法

1. `ng-wanted`フォルダをサーバーの`resources`フォルダに配置します
2. サーバーの`server.cfg`ファイルに`ensure ng-wanted`を追加します
3. サーバーを再起動するか、`refresh`コマンドを実行後に`ensure ng-wanted`を実行します

## 使用方法

### コマンド

- `/wanted` - 警察用指名手配システムメニューを開く
- `/wantedlist` - 一般市民用指名手配リスト表示メニューを開く

### RadialMenu設定

#### 警察用メニュー
以下の設定をQB-Radialmenuの警察メニューに追加します：

```lua
{
    id = 'wanted',
    icon = 'magnifying-glass',
    label = '指名手配メニュー',
    event = 'ng-wanted:client:openMenu',
},
```

#### 一般市民用メニュー
以下の設定をQB-Radialmenuの一般メニューに追加します：

```lua
{
    id = 'wanted',
    icon = 'user-group',
    label = '指名手配リスト',
    event = 'ng-wanted:client:openCivilianMenu',
},
```

## 設定

`shared/config.lua`ファイルで以下の設定が可能です：

- 指名手配可能な最大時間
- 罪名リストと罰金額
- 利用可能なジョブの設定
- 一般市民の閲覧許可設定
- UIのタイトルと表示設定
- **通知音タイプの設定（Native / MP3 / QBCore）**
- データベーステーブル名

## 通知音設定

### 通知音タイプの選択

`shared/config.lua`で通知音タイプを選択できます：

```lua
Config.Notification = {
    enable = true,
    soundType = "native", -- "native" / "mp3" / "qbcore"
    
    -- ネイティブサウンド設定
    nativeSound = {
        sound = "Beep_Red",
        soundSet = "DLC_HEIST_HACKING_SNAKE_SOUNDS"
    },
    
    -- MP3サウンド設定
    mp3Sound = {
        file = "wanted.mp3", -- ui/sounds/フォルダ内のファイル名
        volume = 0.5 -- 0.0 ~ 1.0
    },
    
    -- QBCore通知設定
    qbcoreNotification = {
        type = "警告", -- 通知タイプ
        duration = 15000 -- 表示時間(ミリ秒)
    }
}
```

### 通知音タイプの説明

#### 1. Native（ネイティブサウンド）
- GTA5のゲーム内蔵サウンドを使用
- デフォルト設定
- 設定可能項目：
  - `sound`: サウンド名
  - `soundSet`: サウンドセット名

#### 2. MP3（カスタムMP3ファイル）
- オリジナルのMP3ファイルを使用可能
- 設定方法：
  1. MP3ファイルを `ui/sounds/` フォルダに配置
  2. `mp3Sound.file` にファイル名を設定
  3. `mp3Sound.volume` で音量調整（0.0～1.0）
- 例：警察サイレン、アラーム音など

#### 3. QBCore（QBCore純正通知）
- QBCoreの通知システムと完全統合
- QBCoreの通知音が自動で再生される
- 設定可能項目：
  - `type`: 通知タイプ（"警告"、"成功"、"エラー"など）
  - `duration`: 表示時間（ミリ秒）

### MP3ファイルの追加方法

1. お好みのMP3ファイルを用意
2. `ui/sounds/` フォルダに配置
3. `config.lua` の `mp3Sound.file` にファイル名を設定

例：
```lua
mp3Sound = {
    file = "police_siren.mp3",
    volume = 0.7
}
```

## 機能詳細

### 1. 複数犯罪者の同時選択
複数の犯罪者を選択して同時に指名手配できます。Ctrlキーを押しながらリストをクリックすることで複数選択が可能です。

### 2. 罰金の自動計算
罪名を選択すると、設定されている罰金額が自動的に計算され入力されます。手動で金額を調整することも可能です。

### 3. 指名手配通知
新しい指名手配が登録されると、サーバー内の全プレイヤーに通知が表示され、選択した通知音が鳴ります。通知には犯罪者名、罪名、罰金、指名手配時間が含まれます。

### 4. 一般市民用閲覧機能
一般市民も指名手配リストを閲覧できますが、登録や削除はできません。

## ライセンス

このスクリプトは販売用です。再配布や改変は禁止されています。

## サポート

問題が発生した場合や質問がある場合は、製作者にお問い合わせください。