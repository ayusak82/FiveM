local QBCore = exports['qb-core']:GetCoreObject()

-- サテライトキャノン発射時のエフェクト同期
RegisterServerEvent('ng-satellite:server:fireEffect')
AddEventHandler('ng-satellite:server:fireEffect', function(coords)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then return end
    
    -- 権限チェック
    if not QBCore.Functions.HasPermission(src, Config.Command.permission) then
        TriggerClientEvent('ox_lib:notify', src, {
            title = '通知',
            description = Config.Messages.noPermission,
            type = 'error'
        })
        return
    end
    
    -- 全プレイヤーにエフェクトを同期
    TriggerClientEvent('ng-satellite:client:playEffect', -1, coords)
end)

-- デバッグ用：サーバー起動時のログ
AddEventHandler('onResourceStart', function(resourceName)
    if (GetCurrentResourceName() ~= resourceName) then return end
    print('^2'.. GetCurrentResourceName() .. '^7 has been ^2started^7.')
end)