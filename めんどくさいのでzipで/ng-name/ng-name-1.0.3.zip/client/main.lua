local QBCore = exports['qb-core']:GetCoreObject()
local nameCache = {}
local lastUpdateTime = 0
local UPDATE_INTERVAL = 10000  -- 10秒ごとに更新
local myName = nil -- 自分の名前を保存する変数
local isNameVisible = Config.DefaultVisibility -- 表示状態の変数
local isStreamerMode = false
local myNickname = nil
local useNickname = false
local myTopText = nil -- 上部テキスト用の変数を追加
local useTopText = false -- 上部テキスト表示制御用の変数を追加

-- 視認性チェック関数を追加
local function IsEntityVisible(entity1, entity2)
    return HasEntityClearLosToEntity(entity1, entity2, 17) -- 17 = すべてのオブジェクトを考慮
end

local function GetEntityHeight(entity)
    local min, max = GetModelDimensions(GetEntityModel(entity))
    return math.abs(max.z - min.z)
end

local function CalculateDisplayHeight(ped, isOtherPlayer)
    local vehicle = GetVehiclePedIsIn(ped, false)
    if vehicle ~= 0 then
        -- 車両乗車時
        local vehicleHeight = GetEntityHeight(vehicle)
        return {
            height = (vehicleHeight * 0.5) + Config.Display.height,
            spacing = isOtherPlayer and 0.15 or 0.15  -- 他プレイヤー視点なら広めに
        }
    else
        -- 徒歩時
        return {
            height = Config.Display.height,
            spacing = isOtherPlayer and 0.1 or 0.1  -- 他プレイヤー視点なら広めに
        }
    end
end

-- 名前表示の処理
local function DrawText3D(x, y, z, text, isStreamer)
    local onScreen, _x, _y = GetScreenCoordFromWorldCoord(x, y, z)
    
    if onScreen then
        SetTextScale(Config.Display.scale, Config.Display.scale)
        SetTextFont(Config.Display.font)
        SetTextProportional(true)
        SetTextColour(Config.Display.color.r, Config.Display.color.g, Config.Display.color.b, Config.Display.color.a)
        SetTextOutline()
        SetTextEntry("STRING")
        SetTextCentre(true)
        AddTextComponentString(isStreamer and (text .. ' ' .. Config.StreamerMode.icon) or text)
        DrawText(_x, _y)
        return _y -- Y座標を返す
    end
    return nil
end

-- 上部テキスト表示の処理を追加
local function DrawTopText3D(x, y, z, text, baseY)
    local onScreen, _x, _y = GetScreenCoordFromWorldCoord(x, y, z)
    
    if onScreen then
        -- baseYからの固定オフセットを適用
        _y = baseY - 0.025 -- スクリーン座標での固定オフセット

        SetTextScale(Config.Display.scale, Config.Display.scale)
        SetTextFont(Config.Display.font)
        SetTextProportional(true)
        SetTextColour(Config.TopText.color.r, Config.TopText.color.g, Config.TopText.color.b, Config.TopText.color.a)
        SetTextOutline()
        SetTextEntry("STRING")
        SetTextCentre(true)
        AddTextComponentString(text)
        DrawText(_x, _y)
    end
end

-- UIメニューを更新
local function createNameplateMenu()
    lib.registerContext({
        id = 'nameplate_menu',
        title = 'ネームプレート設定',
        options = {
            {
                title = '表示設定',
                description = '自分の名前を他プレイヤーから見えるようにするかを設定します',
                onSelect = function()
                    isNameVisible = not isNameVisible
                    TriggerServerEvent('ng-name:server:updateVisibility', isNameVisible)
                    
                    lib.notify({
                        title = 'ネームプレート',
                        description = isNameVisible and '名前を表示します' or '名前を非表示にします',
                        type = isNameVisible and 'success' or 'inform',
                        position = Config.UI.position
                    })
                    createNameplateMenu()
                end,
                metadata = {
                    {label = '現在の状態', value = isNameVisible and '表示' or '非表示'}
                }
            },
            {
                title = '配信者モード',
                description = '配信者モードをオン/オフにします',
                onSelect = function()
                    isStreamerMode = not isStreamerMode
                    TriggerServerEvent('ng-name:server:updateStreamerMode', isStreamerMode)
                    
                    lib.notify({
                        title = 'ネームプレート',
                        description = isStreamerMode and '配信者モードをオンにしました' or '配信者モードをオフにしました',
                        type = isStreamerMode and 'success' or 'inform',
                        position = Config.UI.position
                    })
                    createNameplateMenu()
                end,
                metadata = {
                    {label = '現在の状態', value = isStreamerMode and 'オン' or 'オフ'}
                }
            },
            {
                title = 'ニックネーム設定',
                description = 'ニックネームを設定します',
                onSelect = function()
                    local input = lib.inputDialog('ニックネーム設定', {
                        {
                            type = 'input',
                            label = 'ニックネーム',
                            default = myNickname or '', -- 現在の値を表示
                            description = string.format('0-%d文字で入力してください', Config.Nickname.maxLength)
                        }
                    })
    
                    if input and input[1] then
                        TriggerServerEvent('ng-name:server:updateNickname', input[1])
                        -- 即座にローカル変数を更新（サーバーからの応答を待たずに）
                        myNickname = input[1]
                    end
                end
            },
            {
                title = 'ニックネーム表示切替',
                description = 'ニックネームと本名の表示を切り替えます',
                onSelect = function()
                    useNickname = not useNickname
                    TriggerServerEvent('ng-name:server:toggleNickname', useNickname)
                    
                    lib.notify({
                        title = 'ネームプレート',
                        description = useNickname and 'ニックネームを表示します' or '本名を表示します',
                        type = 'success',
                        position = Config.UI.position
                    })
                    createNameplateMenu()
                end,
                metadata = {
                    {label = '現在の表示', value = useNickname and 'ニックネーム' or '本名'}
                }
            },
            {
                title = '上部テキスト設定',
                description = '名前の上に表示するテキストを設定します',
                onSelect = function()
                    local input = lib.inputDialog('上部テキスト設定', {
                        {
                            type = 'input',
                            label = '上部テキスト',
                            default = myTopText or '',
                            description = string.format('0-%d文字で入力してください', Config.TopText.maxLength)
                        }
                    })

                    if input then
                        TriggerServerEvent('ng-name:server:updateTopText', input[1])
                    end
                end
            },
            {
                title = '上部テキスト表示切替',
                description = '上部テキストの表示/非表示を切り替えます',
                onSelect = function()
                    useTopText = not useTopText
                    TriggerServerEvent('ng-name:server:toggleTopText', useTopText)
                    
                    lib.notify({
                        title = 'ネームプレート',
                        description = useTopText and '上部テキストを表示します' or '上部テキストを非表示にします',
                        type = 'success',
                        position = Config.UI.position
                    })
                    createNameplateMenu()
                end,
                metadata = {
                    {label = '現在の状態', value = useTopText and '表示' or '非表示'}
                }
            }
        }
    })
end

-- コマンドの登録（変更なし）
RegisterCommand(Config.Command, function()
    lib.showContext('nameplate_menu')
end)

-- プレイヤーの初期設定（変更なし）
CreateThread(function()
    while not QBCore.Functions.GetPlayerData() do
        Wait(1000)
    end
    
    local PlayerData = QBCore.Functions.GetPlayerData()
    if PlayerData then
        local charinfo = PlayerData.charinfo
        myName = Config.NameFormat:gsub("{firstname}", charinfo.firstname):gsub("{lastname}", charinfo.lastname)
    end

    createNameplateMenu()
    TriggerEvent('chat:addSuggestion', '/' .. Config.Command, 'ネームプレートの設定を開きます')

    local src = GetPlayerServerId(PlayerId())
    TriggerServerEvent('ng-name:server:getPlayerName', src)
end)

-- メインループ部分のみを表示（他のコードは変更なし）
CreateThread(function()
    while true do
        local sleep = 500
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)
        local currentTime = GetGameTimer()
        
        -- 自分の名前と上部テキストの表示（自分の名前は常に表示）
        if myName and isNameVisible then
            local displayHeight = CalculateDisplayHeight(playerPed)
            local displayName = useNickname and myNickname or myName
            
            -- 名前を表示し、Y座標を取得
            local nameCoords = GetOffsetFromEntityInWorldCoords(playerPed, 0.0, 0.0, displayHeight.height)
            local baseY = DrawText3D(nameCoords.x, nameCoords.y, nameCoords.z, displayName, isStreamerMode)
            
            -- 上部テキストの表示（baseYを利用）
            if baseY and useTopText and myTopText then
                local topCoords = GetOffsetFromEntityInWorldCoords(playerPed, 0.0, 0.0, displayHeight.height)
                DrawTopText3D(topCoords.x, topCoords.y, topCoords.z, myTopText, baseY)
            end
            
            sleep = 0
        end

        -- 他プレイヤーの名前表示
        local players = GetActivePlayers()
        if #players > 0 then
            sleep = 0
            for _, playerId in ipairs(players) do
                if playerId ~= PlayerId() then
                    local targetPed = GetPlayerPed(playerId)
                    if DoesEntityExist(targetPed) then
                        local targetCoords = GetEntityCoords(targetPed)
                        local distance = #(playerCoords - targetCoords)

                        -- 距離チェックと視認性チェックを追加
                        if distance <= Config.Display.distance and IsEntityVisible(playerPed, targetPed) then
                            local playerServerId = GetPlayerServerId(playerId)
                            if nameCache[playerServerId] and nameCache[playerServerId].visible then
                                local displayHeight = CalculateDisplayHeight(targetPed)
                                
                                -- プレイヤーが見えている場合のみ名前を表示
                                local nameCoords = GetOffsetFromEntityInWorldCoords(targetPed, 0.0, 0.0, displayHeight.height)
                                local displayName = nameCache[playerServerId].useNickname and nameCache[playerServerId].nickname or nameCache[playerServerId].name
                                local baseY = DrawText3D(nameCoords.x, nameCoords.y, nameCoords.z, displayName, nameCache[playerServerId].streamer)
                                
                                -- 上部テキストの表示（baseYを利用）
                                if baseY and nameCache[playerServerId].useTopText and nameCache[playerServerId].topText then
                                    local topCoords = GetOffsetFromEntityInWorldCoords(targetPed, 0.0, 0.0, displayHeight.height)
                                    DrawTopText3D(topCoords.x, topCoords.y, topCoords.z, nameCache[playerServerId].topText, baseY)
                                end
                            end
                        end
                    end
                end
            end
        end
        Wait(sleep)
    end
end)

-- イベントハンドラーを修正
RegisterNetEvent('ng-name:client:displayName', function(targetId, firstname, lastname, nickname, useNick, streamerMode, topText, useTop)
    local displayName = Config.NameFormat:gsub("{firstname}", firstname):gsub("{lastname}", lastname)
    
    nameCache[targetId] = nameCache[targetId] or {}
    nameCache[targetId] = {
        name = displayName,
        nickname = nickname,
        useNickname = useNick,
        streamer = streamerMode,
        topText = topText,
        useTopText = useTop,
        visible = true
    }
end)

RegisterNetEvent('ng-name:client:loadSettings', function(visibility, streamerMode, nickname, useNick, topText, useTop)
    isNameVisible = visibility
    isStreamerMode = streamerMode
    myNickname = nickname
    useNickname = useNick
    myTopText = topText
    useTopText = useTop
    
    local myServerId = GetPlayerServerId(PlayerId())
    if nameCache[myServerId] then
        nameCache[myServerId].streamer = streamerMode
        nameCache[myServerId].nickname = nickname
        nameCache[myServerId].useNickname = useNick
        nameCache[myServerId].topText = topText
        nameCache[myServerId].useTopText = useTop
        nameCache[myServerId].visible = visibility
    end
    
    createNameplateMenu()
end)

-- 上部テキスト関連のイベントを追加
RegisterNetEvent('ng-name:client:syncTopText', function(playerId, text)
    if nameCache[playerId] then
        nameCache[playerId].topText = text
    end
    
    -- 自分の場合はローカル変数も更新
    if playerId == GetPlayerServerId(PlayerId()) then
        myTopText = text
    end
end)

RegisterNetEvent('ng-name:client:syncTopTextToggle', function(playerId, useTop)
    if nameCache[playerId] then
        nameCache[playerId].useTopText = useTop
    end
    
    -- 自分の場合はローカル変数も更新
    if playerId == GetPlayerServerId(PlayerId()) then
        useTopText = useTop
    end
end)

-- 既存のイベントはそのまま維持
RegisterNetEvent('ng-name:client:syncVisibility', function(playerId, visibility)
    if playerId == GetPlayerServerId(PlayerId()) then
        isNameVisible = visibility
    end
    
    if not visibility then
        if nameCache[playerId] then
            nameCache[playerId].visible = false
        end
    else
        if nameCache[playerId] then
            nameCache[playerId].visible = true
        else
            TriggerServerEvent('ng-name:server:getPlayerName', playerId)
        end
    end
end)

RegisterNetEvent('ng-name:client:syncStreamerMode', function(playerId, enabled)
    if nameCache[playerId] then
        nameCache[playerId].streamer = enabled
    end
end)

RegisterNetEvent('ng-name:client:syncNickname', function(playerId, nickname)
    if nameCache[playerId] then
        nameCache[playerId].nickname = nickname
    end
    
    -- 自分の場合はローカル変数も更新
    if playerId == GetPlayerServerId(PlayerId()) then
        myNickname = nickname
    end
end)

RegisterNetEvent('ng-name:client:syncNicknameToggle', function(playerId, useNick)
    if nameCache[playerId] then
        nameCache[playerId].useNickname = useNick
    end
    
    -- 自分の場合はローカル変数も更新
    if playerId == GetPlayerServerId(PlayerId()) then
        useNickname = useNick
    end
end)

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    local PlayerData = QBCore.Functions.GetPlayerData()
    if PlayerData then
        local charinfo = PlayerData.charinfo
        myName = Config.NameFormat:gsub("{firstname}", charinfo.firstname):gsub("{lastname}", charinfo.lastname)
        
        local src = GetPlayerServerId(PlayerId())
        TriggerServerEvent('ng-name:server:getPlayerName', src)
    end
end)

-- 他のスクリプトからメニューを開くためのイベント
RegisterNetEvent('ng-name:client:openMenu', function()
    lib.showContext('nameplate_menu')
end)