local QBCore = exports['qb-core']:GetCoreObject()
local display = false
local isCivilianMode = false

-- UI display control
function SetDisplay(bool, civMode)
    display = bool
    isCivilianMode = civMode or false
    SetNuiFocus(bool, bool)
    SendNUIMessage({
        type = "ui",
        status = bool,
        config = Config.UI,
        civilianMode = isCivilianMode
    })
end

-- Open police menu event
RegisterNetEvent('ng-wanted:client:openMenu', function()
    if not Config.AllowedJobs[QBCore.Functions.GetPlayerData().job.name] then
        QBCore.Functions.Notify('Only police can use this function', 'error')
        return
    end
    
    -- Get players list from server
    QBCore.Functions.TriggerCallback('ng-wanted:server:getPlayers', function(players)
        -- Get wanted list and display UI
        QBCore.Functions.TriggerCallback('ng-wanted:server:getWantedList', function(wantedList)
            SendNUIMessage({
                type = "init",
                crimesList = Config.Crimes,
                wantedList = wantedList,
                maxWantedTime = Config.MaxWantedTime,
                playersList = players,
                civilianMode = false
            })
            SetDisplay(true, false)
        end)
    end)
end)

-- Open civilian menu event
RegisterNetEvent('ng-wanted:client:openCivilianMenu', function()
    -- Anyone can view
    if not Config.AllowCivilianAccess then
        QBCore.Functions.Notify('This function is currently unavailable', 'error')
        return
    end
    
    -- Get wanted list and display UI
    QBCore.Functions.TriggerCallback('ng-wanted:server:getWantedList', function(wantedList)
        SendNUIMessage({
            type = "init",
            crimesList = Config.Crimes,
            wantedList = wantedList,
            civilianMode = true
        })
        SetDisplay(true, true)
    end)
end)

-- Refresh wanted list event
RegisterNetEvent('ng-wanted:client:refreshWantedList', function()
    if display then
        Citizen.CreateThread(function()
            Citizen.Wait(500) -- Wait a bit before refreshing
            
            QBCore.Functions.TriggerCallback('ng-wanted:server:getWantedList', function(wantedList)
                SendNUIMessage({
                    type = "refreshList",
                    wantedList = wantedList
                })
            end)
        end)
    end
end)

-- NUI callbacks

-- Close UI
RegisterNUICallback('close', function(data, cb)
    SetDisplay(false)
    cb('ok')
end)

-- Add wanted
RegisterNUICallback('addWanted', function(data, cb)
    TriggerServerEvent('ng-wanted:server:addWanted', data)
    cb('ok')
end)

-- Remove wanted
RegisterNUICallback('removeWanted', function(data, cb)
    -- Immediately call server event without confirmation
    TriggerServerEvent('ng-wanted:server:removeWanted', data.id)
    
    -- Return OK immediately
    cb('ok')
end)

-- Initialization
CreateThread(function()
    -- Close UI on resource start
    SetDisplay(false)
end)

-- Wanted notification event
RegisterNetEvent('ng-wanted:client:notifyWanted', function(message)
    -- Play notification sound
    if Config.Notification and Config.Notification.enable then
        local soundType = Config.Notification.soundType
        
        if soundType == "native" then
            -- Play native sound
            local soundConfig = Config.Notification.nativeSound
            PlaySoundFrontend(-1, soundConfig.sound, soundConfig.soundSet, true)
            Citizen.Wait(100)
            PlaySoundFrontend(-1, "TIMER_STOP", "HUD_MINI_GAME_SOUNDSET", true)
            Citizen.Wait(100)
            PlaySoundFrontend(-1, soundConfig.sound, soundConfig.soundSet, true)
            
        elseif soundType == "mp3" then
            -- Play MP3 sound
            local mp3Config = Config.Notification.mp3Sound
            SendNUIMessage({
                type = "playSound",
                sound = mp3Config.file,
                volume = mp3Config.volume
            })
            
        elseif soundType == "qbcore" then
            -- QBCore notification only (no custom sound)
            -- Sound is handled by QBCore
        end
    end
    
    -- Display notification
    if Config.Notification.soundType == "qbcore" then
        -- QBCore native notification
        local qbConfig = Config.Notification.qbcoreNotification
        QBCore.Functions.Notify(message, qbConfig.type, qbConfig.duration)
    else
        -- Standard notification (15 seconds display time)
        QBCore.Functions.Notify(message, "warning", 15000)
    end
end)

-- Register commands
RegisterCommand('wanted', function()
    TriggerEvent('ng-wanted:client:openMenu')
end, false)

RegisterCommand('wantedlist', function()
    TriggerEvent('ng-wanted:client:openCivilianMenu')
end, false)

-- Register key mappings
RegisterKeyMapping('wanted', 'Open wanted system (Police)', 'keyboard', '')
RegisterKeyMapping('wantedlist', 'View wanted list (Civilian)', 'keyboard', '')
