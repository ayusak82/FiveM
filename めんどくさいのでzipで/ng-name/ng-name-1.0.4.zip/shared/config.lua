Config = {}

-- 上部テキストの設定を追加
Config.TopText = {
    maxLength = 100, -- 上部テキストの最大長
    minLength = 0,  -- 上部テキストの最小長
    enabled = true, -- デフォルトで有効かどうか
    height = 0.07,   -- 名前との距離（上方向）
    -- テキストの色 (RGBA)
    color = {
        r = 255,
        g = 255,
        b = 255,
        a = 255
    }
}

Config.StreamerMode = {
    enabled = false,
    icon = '🛰'
}

Config.Nickname = {
    maxLength = 100,
    minLength = 0,
}

Config.Display = {
    distance = 15.0,
    scale = 0.3,
    height = 1.0,
    font = 0,
    color = {
        r = 255,
        g = 255,
        b = 255,
        a = 255
    }
}

Config.Command = 'nameplate'
Config.DefaultVisibility = true

Config.UI = {
    position = 'right-center'
}

Config.NameFormat = "{firstname} {lastname}"