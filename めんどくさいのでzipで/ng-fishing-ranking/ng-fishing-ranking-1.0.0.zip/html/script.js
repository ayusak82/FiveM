let playerCitizenId = null;

// NUIメッセージリスナー
window.addEventListener('message', function(event) {
    const data = event.data;

    if (data.action === 'open') {
        document.getElementById('container').classList.remove('hidden');
        playerCitizenId = data.citizenId;
        
        // ランキングデータがある場合は表示
        if (data.experienceRankings) {
            displayRankings('experience', data.experienceRankings);
        }
        
        // プレイヤー情報を表示
        if (data.playerRank) {
            document.getElementById('playerRank').textContent = data.playerRank;
        }
        
        if (data.playerExp) {
            document.getElementById('playerExp').textContent = data.playerExp;
        }
    } else if (data.action === 'close') {
        document.getElementById('container').classList.add('hidden');
    } else if (data.action === 'updateRankings') {
        if (data.type === 'experience' && data.rankings) {
            displayRankings('experience', data.rankings);
        }
    }
});

// 閉じるボタン
document.getElementById('closeBtn').addEventListener('click', function() {
    document.getElementById('container').classList.add('hidden');
    fetch(`https://${GetParentResourceName()}/closeUI`, {
        method: 'POST'
    });
});

// ランキングデータを表示する関数
function displayRankings(type, rankings) {
    const tbody = document.getElementById(`${type}-tbody`);
    tbody.innerHTML = '';
    
    rankings.forEach((player, index) => {
        const row = document.createElement('tr');
        
        // 自分のデータをハイライト
        if (player.citizenid === playerCitizenId) {
            row.classList.add('highlight');
        }
        
        const rankCell = document.createElement('td');
        rankCell.textContent = index + 1;
        row.appendChild(rankCell);
        
        const nameCell = document.createElement('td');
        nameCell.textContent = player.name || `プレイヤー #${player.citizenid.substring(0, 5)}`;
        row.appendChild(nameCell);
        
        const valueCell = document.createElement('td');
        
        if (type === 'experience') {
            // 経験値に応じたレベル表示
            const level = calculateLevel(player.experience);
            valueCell.textContent = `Lv ${level} (${player.experience} EXP)`;
        } else {
            valueCell.textContent = player.catches || 0;
        }
        
        row.appendChild(valueCell);
        tbody.appendChild(row);
    });
}

// 経験値からレベルを計算する関数
function calculateLevel(experience) {
    // 仮の計算式: 100EXPごとにレベルアップ
    return Math.floor(experience / 100) + 1;
}

// ESCキーでUIを閉じる
document.addEventListener('keyup', function(event) {
    if (event.key === 'Escape') {
        document.getElementById('container').classList.add('hidden');
        fetch(`https://${GetParentResourceName()}/closeUI`, {
            method: 'POST'
        });
    }
});