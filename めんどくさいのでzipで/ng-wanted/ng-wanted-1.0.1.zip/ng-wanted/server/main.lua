local QBCore = exports['qb-core']:GetCoreObject()

-- データベーステーブルの作成
CreateThread(function()
    MySQL.Async.execute([[
        CREATE TABLE IF NOT EXISTS ]]..Config.DatabaseTable..[[ (
            id INT AUTO_INCREMENT PRIMARY KEY,
            criminal_name VARCHAR(255) NOT NULL,
            crimes TEXT NOT NULL,
            fine INT NOT NULL,
            wanted_until TIMESTAMP NOT NULL,
            added_by VARCHAR(50) NOT NULL,
            added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ]], {})
end)

-- 指名手配リストの取得
QBCore.Functions.CreateCallback('ng-wanted:server:getWantedList', function(source, cb)
    MySQL.Async.fetchAll('SELECT * FROM '..Config.DatabaseTable..' WHERE wanted_until > NOW()', {}, function(result)
        if result and type(result) == "table" then
            -- 各犯罪者の罪名文字列をテーブルに変換
            for i=1, #result do
                if result[i].crimes then
                    result[i].crimes = json.decode(result[i].crimes)
                else
                    result[i].crimes = {}
                end
            end
            cb(result)
        else
            cb({})
        end
    end)
end)

-- プレイヤーリストの取得
QBCore.Functions.CreateCallback('ng-wanted:server:getPlayers', function(source, cb)
    local players = {}
    local src = source
    local srcPlayer = QBCore.Functions.GetPlayer(src)
    
    if not srcPlayer then return cb({}) end
    
    -- 警察職のみアクセス可能
    if not Config.AllowedJobs[srcPlayer.PlayerData.job.name] then
        return cb({})
    end
    
    -- すべてのプレイヤーを取得
    for _, player in pairs(QBCore.Functions.GetPlayers()) do
        local targetPlayer = QBCore.Functions.GetPlayer(player)
        if targetPlayer then
            table.insert(players, {
                id = player,
                name = targetPlayer.PlayerData.charinfo.firstname .. ' ' .. targetPlayer.PlayerData.charinfo.lastname,
                citizenid = targetPlayer.PlayerData.citizenid
            })
        end
    end
    
    cb(players)
end)

-- 新しい指名手配の追加
RegisterNetEvent('ng-wanted:server:addWanted', function(data)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then return end
    
    -- ジョブチェック
    if not Config.AllowedJobs[Player.PlayerData.job.name] then
        TriggerClientEvent('QBCore:Notify', src, '警察関係者のみがこの機能を使用できます', 'error')
        return
    end
    
    -- データの検証
    if not data.criminalNames or #data.criminalNames == 0 then
        TriggerClientEvent('QBCore:Notify', src, '犯罪者を少なくとも1人選択してください', 'error')
        return
    end
    
    if not data.crimes or #data.crimes == 0 then
        TriggerClientEvent('QBCore:Notify', src, '少なくとも1つの罪名を選択してください', 'error')
        return
    end
    
    local fineAmount = tonumber(data.fine)
    if not fineAmount or fineAmount <= 0 then
        TriggerClientEvent('QBCore:Notify', src, '罰金額を正しく設定してください', 'error')
        return
    end
    
    -- wantedTimeの値を安全に取得し、最大値を超えないよう保証
    local wantedTimeMinutes = tonumber(data.wantedTime) or 0
    
    -- データの検証と安全処理
    if not wantedTimeMinutes or wantedTimeMinutes <= 0 then
        TriggerClientEvent('QBCore:Notify', src, '指名手配時間は1分以上で設定してください', 'error')
        return
    end
    
    -- 最大値を超えた場合は最大値に自動調整して処理を続行
    if wantedTimeMinutes > Config.MaxWantedTime then
        wantedTimeMinutes = Config.MaxWantedTime
        TriggerClientEvent('QBCore:Notify', src, '指名手配時間が最大値(' .. Config.MaxWantedTime .. '分)を超えています。自動的に' .. Config.MaxWantedTime .. '分に調整しました。', 'warning')
    end
    
    -- 単純に現在時刻に分数を秒に変換して追加
    local currentTimestamp = os.time()
    local wantedSeconds = wantedTimeMinutes * 60
    local wantedUntil = currentTimestamp + wantedSeconds
    
    -- MySQLのタイムスタンプ形式に変換
    local formattedTime = os.date('%Y-%m-%d %H:%M:%S', wantedUntil)
    
    -- 追加された犯罪者の名前をリストアップ
    local addedCriminals = {}
    
    -- すべての犯罪者に対して処理
    for i, criminalName in ipairs(data.criminalNames) do
        -- データベースに保存
        local success, result = pcall(function()
            MySQL.Async.insert('INSERT INTO '..Config.DatabaseTable..' (criminal_name, crimes, fine, wanted_until, added_by) VALUES (?, ?, ?, ?, ?)', {
                criminalName,
                json.encode(data.crimes),
                fineAmount,
                formattedTime,
                Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname
            }, function(id)
                if id then
                    -- 成功した場合は名前をリストに追加
                    table.insert(addedCriminals, criminalName)
                    
                    -- すべての処理が完了したらメッセージを送信
                    if i == #data.criminalNames then
                        -- 成功メッセージを登録者に送信
                        TriggerClientEvent('QBCore:Notify', src, #addedCriminals .. '人の犯罪者を指名手配リストに追加しました', 'success')
                        
                        -- 犯罪者通知を全体に送信
                        if #addedCriminals > 0 then
                            local notifyMsg = ''
                            if #addedCriminals == 1 then
                                notifyMsg = addedCriminals[1] .. 'が指名手配されました'
                            else
                                notifyMsg = #addedCriminals .. '人の犯罪者が指名手配されました'
                            end
                            
                            -- 指名手配の詳細情報を作成
                            local crimesInfo = {}
                            for _, crimeIndex in ipairs(data.crimes) do
                                if Config.Crimes[crimeIndex + 1] then -- JavaScriptは0始まり、Luaは1始まりなので調整
                                    table.insert(crimesInfo, Config.Crimes[crimeIndex + 1].label)
                                end
                            end
                            
                            local detailMsg = ''
                            if #crimesInfo > 0 then
                                detailMsg = '罪名: ' .. table.concat(crimesInfo, ', ') .. ' / 罰金: $' .. data.fine .. ' / 指名手配時間: ' .. data.wantedTime .. '分'
                            end
                            
                            -- 全プレイヤーに通知
                            TriggerClientEvent('ng-wanted:client:notifyWanted', -1, notifyMsg .. '\n' .. detailMsg)
                            
                            -- 少し間を開けて再度通知音を鳴らす（より目立たせるため）
                            Citizen.Wait(5000) -- 5秒待つ
                            TriggerClientEvent('ng-wanted:client:notifyWanted', -1, '⚠️ 指名手配リスト更新 ⚠️')
                            
                            -- 全クライアントに指名手配リストの更新を通知
                            TriggerClientEvent('ng-wanted:client:refreshWantedList', -1)
                        end
                    end
                else
                    TriggerClientEvent('QBCore:Notify', src, criminalName .. 'の指名手配追加に失敗しました', 'error')
                end
            end)
        end)
        
        if not success then
            print('データベース操作エラー:', result)
            TriggerClientEvent('QBCore:Notify', src, 'システムエラーが発生しました。管理者にお問い合わせください。', 'error')
        end
    end
end)

-- 指名手配の削除 (完全に書き直し)
RegisterNetEvent('ng-wanted:server:removeWanted', function(wantedId)
    local src = source
    
    -- シンプルな削除実装（エラーハンドリングを最小限に）
    if type(wantedId) ~= "number" then
        wantedId = tonumber(wantedId) or 0
    end
    
    if wantedId <= 0 then
        return
    end
    
    -- 単純に削除だけを行う 
    MySQL.Sync.execute('DELETE FROM '..Config.DatabaseTable..' WHERE id = ?', {wantedId})
    
    -- 全クライアントにリストの更新を通知
    TriggerClientEvent('ng-wanted:client:refreshWantedList', -1)
end)

-- 期限切れの指名手配を自動削除（サーバー起動時と定期的に実行）
local function cleanExpiredWanted()
    MySQL.Async.execute('DELETE FROM '..Config.DatabaseTable..' WHERE wanted_until < NOW()', {}, function(rowsChanged)
        if rowsChanged and type(rowsChanged) == "number" and rowsChanged > 0 then
            print('期限切れの指名手配 ' .. rowsChanged .. ' 件を削除しました')
            -- 全クライアントに指名手配リストの更新を通知
            TriggerClientEvent('ng-wanted:client:refreshWantedList', -1)
        end
    end)
end

-- サーバー起動時に実行
CreateThread(function()
    cleanExpiredWanted()
    
    -- 5分ごとに期限切れの指名手配をチェック
    while true do
        Wait(5 * 60 * 1000) -- 5分
        cleanExpiredWanted()
    end
end)