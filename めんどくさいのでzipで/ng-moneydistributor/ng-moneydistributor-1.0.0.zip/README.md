# NG Money Distributor

FiveM サーバー用のお金分配システム。近くのプレイヤーに素早く簡単にお金を配布できます。

## 概要

このスクリプトを使用すると、プレイヤーは近くにいる他のプレイヤーにお金を簡単に分配することができます。現金または銀行送金で指定した金額を複数のプレイヤーに同時に送ることができます。

## 機能

- 近くのプレイヤーを自動検出
- 現金または銀行送金を選択可能
- 複数プレイヤーへの同時送金
- 直感的なUIを使用した簡単な操作
- プレイヤーやCitizenIDの詳細表示
- 送金完了時の通知システム

## 要件

- qb-core
- ox_lib
- oxmysql
- ox_target
- ox_inventory

## インストール方法

1. このリポジトリをダウンロードします
2. `ng-moneydistributor` フォルダをサーバーの `resources` ディレクトリに配置します
3. `server.cfg` に以下の行を追加します:
   ```
   ensure ng-moneydistributor
   ```
4. サーバーを再起動します

## 使用方法

### エクスポート機能を使用

他のスクリプトから直接呼び出すことも可能です:

```lua
-- 他のクライアントスクリプトからの呼び出し例
exports['ng-moneydistributor']:OpenMenu()
```

## 設定

`shared/config.lua` ファイルで以下の設定をカスタマイズできます:

```lua
Config = {}

-- デフォルト設定
Config.DefaultAmount = 1000 -- デフォルトの金額
Config.MaxDistance = 10.0 -- プレイヤー検出の最大距離（メートル）

-- UI設定
Config.UITitle = 'お金分配システム'
Config.UIIcon = 'money-bill-transfer'
Config.UIPosition = 'middle'
```

## クレジット

作成者: NCCGr
バージョン: 1.0.0