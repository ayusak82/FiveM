local QBCore = exports['qb-core']:GetCoreObject()

-- プレイヤーデータ
local PlayerData = {}
local blips = {}

-- 関数を事前宣言
local ShowAdminMenu
local ShowAddItemMenu

-- アイテム追加メニューを表示
ShowAddItemMenu = function(shopId)
    -- アイテムリストを取得
    local allItems = {}
    
    -- 通常アイテムと武器を追加
    for k, v in pairs(exports.ox_inventory:Items()) do
        allItems[#allItems + 1] = {
            name = k,
            label = v.label,
            type = v.weapon and 'weapon' or 'item'
        }
    end
    
    -- アルファベット順にソート
    table.sort(allItems, function(a, b)
        return a.label:lower() < b.label:lower()
    end)
    
    -- 検索用の入力ダイアログ
    local input = lib.inputDialog('アイテムを検索', {
        { type = 'input', label = '検索キーワード', description = '空白で全アイテム表示' }
    })
    
    if not input then return end
    local searchTerm = input[1] and input[1]:lower() or ''
    
    -- 検索結果に基づいてオプションを作成
    local options = {}
    for _, item in ipairs(allItems) do
        if searchTerm == '' or item.label:lower():find(searchTerm) or item.name:lower():find(searchTerm) then
            options[#options + 1] = {
                title = item.label,
                description = string.format('アイテムID: %s (%s)', item.name, item.type),
                image = string.format('nui://ox_inventory/web/images/%s.png', item.name),
                onSelect = function()
                    local priceInput = lib.inputDialog(string.format('%s の価格設定', item.label), {
                        { type = 'number', label = '購入価格', description = '0の場合は購入不可', required = true, min = 0 },
                        { type = 'number', label = '売却価格', description = '0の場合は売却不可', required = true, min = 0 }
                    })
                    
                    if priceInput then
                        local alert = lib.alertDialog({
                            header = '追加内容の確認',
                            content = string.format([[
アイテム名: %s
表示名: %s
購入価格: $%s
売却価格: $%s

この内容で追加しますか？]], item.name, item.label, priceInput[1], priceInput[2]),
                            centered = true,
                            cancel = true
                        })
                        
                        if alert == 'confirm' then
                            local success = lib.callback.await('ng-shop:server:updateItem', false, shopId, {
                                item_name = item.name,
                                label = item.label,
                                buy_price = priceInput[1],
                                sell_price = priceInput[2]
                            })
                            
                            if success then
                                lib.notify({type = 'success', description = 'アイテムを追加しました'})
                                ShowAdminMenu(shopId)
                            end
                        end
                    end
                end
            }
        end
    end
    
    -- ページネーション（オプション数が多い場合の対策）
    if #options > 0 then
        lib.registerContext({
            id = 'add_item_menu',
            title = string.format('アイテム追加%s', searchTerm ~= '' and string.format(' (検索: %s)', searchTerm) or ''),
            menu = 'shop_admin_menu',
            options = options
        })
        
        lib.showContext('add_item_menu')
    else
        lib.notify({type = 'error', description = '該当するアイテムが見つかりません'})
        ShowAddItemMenu(shopId)  -- 検索をやり直す
    end
end

-- 管理者メニューを表示
ShowAdminMenu = function(shopId)
    local items = lib.callback.await('ng-shop:server:getShopItems', false, shopId)
    local options = {
        {
            title = '新しいアイテムを追加',
            description = 'アイテムリストから選択して追加',
            icon = 'plus',
            onSelect = function()
                ShowAddItemMenu(shopId)
            end
        }
    }
    
    if items then
        for _, item in ipairs(items) do
            options[#options + 1] = {
                title = item.label,
                description = item.item_name,
                icon = 'box',
                metadata = {
                    {label = '購入価格', value = string.format('$%s', item.buy_price)},
                    {label = '売却価格', value = string.format('$%s', item.sell_price)}
                },
                image = string.format('nui://ox_inventory/web/images/%s.png', item.item_name),
                onSelect = function()
                    local itemMenu = {
                        {
                            title = '編集',
                            description = 'アイテムの情報を編集',
                            icon = 'edit',
                            onSelect = function()
                                local input = lib.inputDialog('アイテムの編集', {
                                    {type = 'input', label = 'ラベル', description = '表示名を入力', required = true, default = item.label},
                                    {type = 'number', label = '購入価格', description = '0の場合は購入不可', required = true, default = item.buy_price, min = 0},
                                    {type = 'number', label = '売却価格', description = '0の場合は売却不可', required = true, default = item.sell_price, min = 0}
                                })
                                
                                if input then
                                    local alert = lib.alertDialog({
                                        header = '変更内容の確認',
                                        content = string.format([[
アイテム名: %s
表示名: %s → %s
購入価格: $%s → $%s
売却価格: $%s → $%s

この内容で更新しますか？]], item.item_name, item.label, input[1], item.buy_price, input[2], item.sell_price, input[3]),
                                        centered = true,
                                        cancel = true
                                    })
                                    
                                    if alert == 'confirm' then
                                        local success = lib.callback.await('ng-shop:server:updateItem', false, shopId, {
                                            item_name = item.item_name,
                                            label = input[1],
                                            buy_price = input[2],
                                            sell_price = input[3]
                                        })
                                        
                                        if success then
                                            lib.notify({type = 'success', description = 'アイテムを更新しました'})
                                            ShowAdminMenu(shopId)
                                        end
                                    end
                                end
                            end
                        },
                        {
                            title = '削除',
                            description = 'アイテムを削除',
                            icon = 'trash',
                            onSelect = function()
                                local alert = lib.alertDialog({
                                    header = '削除の確認',
                                    content = string.format([[
以下のアイテムを削除します：
%s (%s)

購入価格: $%s
売却価格: $%s

この操作は取り消せません。
本当に削除しますか？]], item.label, item.item_name, item.buy_price, item.sell_price),
                                    centered = true,
                                    cancel = true
                                })
                                
                                if alert == 'confirm' then
                                    local success = lib.callback.await('ng-shop:server:deleteItem', false, shopId, item.item_name)
                                    if success then
                                        lib.notify({type = 'success', description = 'アイテムを削除しました'})
                                        ShowAdminMenu(shopId)
                                    end
                                end
                            end
                        }
                    }

                    lib.registerContext({
                        id = 'item_action_menu',
                        title = item.label,
                        menu = 'shop_admin_menu',
                        options = itemMenu
                    })

                    lib.showContext('item_action_menu')
                end
            }
        end
    end

    lib.registerContext({
        id = 'shop_admin_menu',
        title = 'アイテム管理',
        menu = 'shop_location_menu',
        options = options
    })

    lib.showContext('shop_admin_menu')
end

-- プレイヤーのロード時
RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    PlayerData = QBCore.Functions.GetPlayerData()
    RefreshShops()
end)

-- ジョブ変更時
RegisterNetEvent('QBCore:Client:OnJobUpdate', function(JobInfo)
    PlayerData.job = JobInfo
end)

-- ショップの更新イベント
RegisterNetEvent('ng-shop:client:refreshShops', function()
    RefreshShops()
    -- メニューが開いている場合は更新
    if lib.getOpenMenu() then
        ShowShopLocationMenu()
    end
end)

-- ショップデータの更新
function RefreshShops()
    local shops = lib.callback.await('ng-shop:server:getShopLocations', false)
    if not shops then return end

    -- 既存のブリップを更新または削除
    for shopId, existingBlip in pairs(blips) do
        local shopStillExists = false
        for _, shop in pairs(shops) do
            if shop.shop_id == shopId then
                shopStillExists = true
                -- ブリップの更新（有効/無効の切り替え）
                if shop.blip_enabled then
                    SetBlipCoords(existingBlip, shop.coords_x, shop.coords_y, shop.coords_z)
                    SetBlipScale(existingBlip, shop.blip_scale)
                    SetBlipColour(existingBlip, shop.blip_color)
                    SetBlipSprite(existingBlip, shop.blip_sprite)
                    BeginTextCommandSetBlipName("STRING")
                    AddTextComponentString(shop.label)
                    EndTextCommandSetBlipName(existingBlip)
                else
                    RemoveBlip(existingBlip)
                    blips[shopId] = nil
                end
                break
            end
        end
        -- ショップが削除された場合
        if not shopStillExists then
            RemoveBlip(existingBlip)
            blips[shopId] = nil
        end
    end

    -- 新しいショップのブリップを作成
    for _, shop in pairs(shops) do
        if shop.blip_enabled and not blips[shop.shop_id] then
            local blip = AddBlipForCoord(shop.coords_x, shop.coords_y, shop.coords_z)
            SetBlipSprite(blip, shop.blip_sprite)
            SetBlipDisplay(blip, 4)
            SetBlipScale(blip, shop.blip_scale)
            SetBlipColour(blip, shop.blip_color)
            SetBlipAsShortRange(blip, true)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString(shop.label)
            EndTextCommandSetBlipName(blip)
            blips[shop.shop_id] = blip
        end
    end
end

-- ジョブチェック
local function HasRequiredJob(shop)
    if not shop.jobs then return true end
    if not PlayerData.job then return false end
    
    local jobName = PlayerData.job.name
    local jobGrade = PlayerData.job.grade.level
    
    if shop.jobs[jobName] then
        if shop.jobs[jobName] == 0 then return true end
        return jobGrade >= shop.jobs[jobName]
    end
    
    return shop.jobs['civilian'] and shop.jobs['civilian'] == 0
end

-- job選択用のメニューを表示
local function ShowJobSelection(shopId, currentJobs)
    local options = {
        {
            title = '職業を追加',
            description = '新しい職業を追加します',
            icon = 'plus',
            onSelect = function()
                local input = lib.inputDialog('職業の追加', {
                    {type = 'input', label = '職業名（例: police）', required = true},
                    {type = 'number', label = '最小グレード（0=全グレード可）', required = true, default = 0, min = 0}
                })
                
                if input then
                    local jobs = currentJobs or {}
                    jobs[input[1]] = input[2]
                    
                    local success = lib.callback.await('ng-shop:server:updateShopJobs', false, shopId, jobs)
                    if success then
                        lib.notify({type = 'success', description = '職業を追加しました'})
                        ShowJobSelection(shopId, jobs)
                    end
                end
            end
        }
    }

    -- 現在設定されている職業を表示
    if currentJobs then
        for jobName, grade in pairs(currentJobs) do
            options[#options + 1] = {
                title = jobName,
                description = string.format('最小グレード: %s', grade),
                icon = 'briefcase',
                onSelect = function()
                    local alert = lib.alertDialog({
                        header = '確認',
                        content = string.format('%sを削除しますか？', jobName),
                        centered = true,
                        labels = {
                            confirm = '削除',
                            cancel = 'キャンセル'
                        }
                    })
                    
                    if alert == 'confirm' then
                        local jobs = currentJobs
                        jobs[jobName] = nil
                        
                        local success = lib.callback.await('ng-shop:server:updateShopJobs', false, shopId, jobs)
                        if success then
                            lib.notify({type = 'success', description = '職業を削除しました'})
                            ShowJobSelection(shopId, jobs)
                        end
                    end
                end
            }
        end
    end

    lib.registerContext({
        id = 'job_selection_menu',
        title = '職業設定',
        menu = 'shop_location_actions',
        options = options
    })

    lib.showContext('job_selection_menu')
end

-- ショップ管理メニューを表示
local function ShowShopLocationMenu()
    local ped = PlayerPedId()
    local currentCoords = GetEntityCoords(ped)
    local currentHeading = GetEntityHeading(ped)

    local shops = lib.callback.await('ng-shop:server:getShopLocations', false)
    local options = {
        {
            title = '新しいショップを追加',
            description = '現在の位置にショップを作成',
            icon = 'plus',
            onSelect = function()
                local input = lib.inputDialog('ショップの追加', {
                    {type = 'input', label = 'ショップID (例: shop1)', required = true},
                    {type = 'input', label = 'ショップ名', required = true},
                    {type = 'checkbox', label = 'Blipを表示', checked = true},
                    {type = 'number', label = 'Blipスプライト', default = 59},
                    {type = 'number', label = 'Blipカラー', default = 25},
                    {type = 'number', label = 'Blipスケール', default = 0.7, step = 0.1}
                })
                
                if input then
                    local success = lib.callback.await('ng-shop:server:updateShopLocation', false, {
                        shop_id = input[1],
                        label = input[2],
                        coords_x = currentCoords.x,
                        coords_y = currentCoords.y,
                        coords_z = currentCoords.z,
                        heading = currentHeading,
                        jobs = {},
                        blip_enabled = input[3],
                        blip_sprite = input[4],
                        blip_color = input[5],
                        blip_scale = input[6]
                    })
                    
                    if success then
                        lib.notify({type = 'success', description = 'ショップを追加しました'})
                        ShowShopLocationMenu()
                    end
                end
            end
        }
    }

    if shops then
        for _, shop in ipairs(shops) do
            options[#options + 1] = {
                title = shop.label,
                description = string.format('ID: %s', shop.shop_id),
                onSelect = function()
                    local shopMenu = {
                        {
                            title = 'アイテム管理',
                            description = 'ショップのアイテムを管理',
                            icon = 'box',
                            onSelect = function()
                                ShowAdminMenu(shop.shop_id)
                            end
                        },
                        {
                            title = '編集',
                            description = 'ショップの設定を編集',
                            icon = 'edit',
                            onSelect = function()
                                local input = lib.inputDialog('ショップの編集', {
                                    {type = 'input', label = 'ショップ名', required = true, default = shop.label},
                                    {type = 'checkbox', label = 'Blipを表示', checked = shop.blip_enabled},
                                    {type = 'number', label = 'Blipスプライト', default = shop.blip_sprite},
                                    {type = 'number', label = 'Blipカラー', default = shop.blip_color},
                                    {type = 'number', label = 'Blipスケール', default = shop.blip_scale, step = 0.1}
                                })
                                
                                if input then
                                    local success = lib.callback.await('ng-shop:server:updateShopLocation', false, {
                                        shop_id = shop.shop_id,
                                        label = input[1],
                                        coords_x = shop.coords_x,
                                        coords_y = shop.coords_y,
                                        coords_z = shop.coords_z,
                                        heading = shop.heading,
                                        jobs = shop.jobs,
                                        blip_enabled = input[2],
                                        blip_sprite = input[3],
                                        blip_color = input[4],
                                        blip_scale = input[5]
                                    })
                                    
                                    if success then
                                        lib.notify({type = 'success', description = 'ショップを更新しました'})
                                        ShowShopLocationMenu()
                                    end
                                end
                            end
                        },
                        {
                            title = '座標を更新',
                            description = '現在の位置に移動',
                            icon = 'location-dot',
                            onSelect = function()
                                local success = lib.callback.await('ng-shop:server:updateShopLocation', false, {
                                    shop_id = shop.shop_id,
                                    label = shop.label,
                                    coords_x = currentCoords.x,
                                    coords_y = currentCoords.y,
                                    coords_z = currentCoords.z,
                                    heading = currentHeading,
                                    jobs = shop.jobs,
                                    blip_enabled = shop.blip_enabled,
                                    blip_sprite = shop.blip_sprite,
                                    blip_color = shop.blip_color,
                                    blip_scale = shop.blip_scale
                                })
                                
                                if success then
                                    lib.notify({type = 'success', description = '座標を更新しました'})
                                    ShowShopLocationMenu()
                                end
                            end
                        },
                        {
                            title = '職業設定',
                            description = 'アクセス可能な職業を設定',
                            icon = 'briefcase',
                            onSelect = function()
                                ShowJobSelection(shop.shop_id, shop.jobs)
                            end
                        },
                        {
                            title = '削除',
                            description = 'ショップを削除',
                            icon = 'trash',
                            onSelect = function()
                                local alert = lib.alertDialog({
                                    header = '確認',
                                    content = string.format('%sを削除しますか？', shop.label),
                                    centered = true,
                                    labels = {
                                        confirm = '削除',
                                        cancel = 'キャンセル'
                                    }
                                })
                                
                                if alert == 'confirm' then
                                    local success = lib.callback.await('ng-shop:server:deleteShopLocation', false, shop.shop_id)
                                    if success then
                                        lib.notify({type = 'success', description = 'ショップを削除しました'})
                                        ShowShopLocationMenu()
                                    end
                                end
                            end
                        }
                    }

                    lib.registerContext({
                        id = 'shop_location_actions',
                        title = shop.label,
                        menu = 'shop_location_menu',
                        options = shopMenu
                    })

                    lib.showContext('shop_location_actions')
                end
            }
        end
    end

    lib.registerContext({
        id = 'shop_location_menu',
        title = 'ショップ管理',
        options = options
    })

    lib.showContext('shop_location_menu')
end

-- ショップメニューを表示
local function ShowShopMenu(shopId, shopData)
    local items = lib.callback.await('ng-shop:server:getShopItems', false, shopId)
    
    -- メインメニューのオプション
    local options = {
        {
            title = '購入メニュー',
            description = '商品を購入します',
            icon = 'cart-shopping',
            menu = 'shop_buy_menu'
        }
    }
    
    -- 売却可能なアイテムがあれば売却メニューを追加
    if #items > 0 and items[1].sell_price > 0 then
        options[#options + 1] = {
            title = '売却メニュー',
            description = 'アイテムを売却します',
            icon = 'money-bill-transfer',
            menu = 'shop_sell_menu'
        }
    end
    
    -- 管理者メニュー
    local isAdmin = lib.callback.await('ng-shop:server:isAdmin', false)
    if isAdmin then
        options[#options + 1] = {
            title = '管理者メニュー',
            description = 'ショップの管理を行います',
            icon = 'gear',
            onSelect = function()
                ShowAdminMenu(shopId)
            end
        }
    end
    
    -- 購入メニューの作成
    local buyOptions = {}
    for _, item in ipairs(items) do
        if item.buy_price > 0 then
            buyOptions[#buyOptions + 1] = {
                title = item.label,
                description = string.format('購入価格: $%s', item.buy_price),
                icon = 'box',
                metadata = {
                    {label = '在庫', value = '∞'},
                    {label = '価格', value = string.format('$%s', item.buy_price)}
                },
                image = string.format('nui://ox_inventory/web/images/%s.png', item.item_name),
                onSelect = function()
                    local input = lib.inputDialog(string.format('%s を購入', item.label), {
                        {type = 'number', label = '数量', required = true, min = 1, max = 100000}
                    })
                    
                    if input then
                        local quantity = input[1]
                        local totalPrice = item.buy_price * quantity
                        
                        -- 支払い方法選択メニューを表示
                        lib.registerContext({
                            id = 'payment_method_menu',
                            title = string.format('%s の支払い方法', item.label),
                            menu = 'shop_buy_menu',
                            options = {
                                {
                                    title = '現金で支払う',
                                    description = string.format('合計金額: $%s', totalPrice),
                                    icon = 'money-bill',
                                    onSelect = function()
                                        local success = lib.callback.await('ng-shop:server:buyItem', false, shopId, item.item_name, quantity, 'cash')
                                        if success then
                                            ShowShopMenu(shopId, shopData)
                                        end
                                    end
                                },
                                {
                                    title = '銀行で支払う',
                                    description = string.format('合計金額: $%s', totalPrice),
                                    icon = 'credit-card',
                                    onSelect = function()
                                        local success = lib.callback.await('ng-shop:server:buyItem', false, shopId, item.item_name, quantity, 'bank')
                                        if success then
                                            ShowShopMenu(shopId, shopData)
                                        end
                                    end
                                }
                            }
                        })
                        
                        lib.showContext('payment_method_menu')
                    end
                end
            }
        end
    end
    
    -- 売却メニューの作成
    local sellOptions = {}
    for _, item in ipairs(items) do
        if item.sell_price > 0 then
            sellOptions[#sellOptions + 1] = {
                title = item.label,
                description = string.format('売却価格: $%s', item.sell_price),
                icon = 'money-bill',
                metadata = {
                    {label = '価格', value = string.format('$%s', item.sell_price)}
                },
                image = string.format('nui://ox_inventory/web/images/%s.png', item.item_name),
                onSelect = function()
                    local input = lib.inputDialog(string.format('%s を売却', item.label), {
                        {type = 'number', label = '数量', required = true, min = 1, max = 100000}
                    })
                    
                    if input then
                        local quantity = input[1]
                        local totalPrice = item.sell_price * quantity
                        
                        local alert = lib.alertDialog({
                            header = '売却確認',
                            content = string.format('%s を %d 個売却します\n受取金額: $%s', item.label, quantity, totalPrice),
                            centered = true,
                            cancel = true,
                            labels = {
                                confirm = '売却する',
                                cancel = 'キャンセル'
                            }
                        })
                        
                        if alert == 'confirm' then
                            local success = lib.callback.await('ng-shop:server:sellItem', false, shopId, item.item_name, quantity)
                            if success then
                                ShowShopMenu(shopId, shopData)
                            end
                        end
                    end
                end
            }
        end
    end
    
    -- メニューの登録
    if #buyOptions > 0 then
        lib.registerContext({
            id = 'shop_buy_menu',
            title = string.format('%s - 購入', shopData.label),
            menu = 'shop_main_menu',
            options = buyOptions
        })
    end
    
    if #sellOptions > 0 then
        lib.registerContext({
            id = 'shop_sell_menu',
            title = string.format('%s - 売却', shopData.label),
            menu = 'shop_main_menu',
            options = sellOptions
        })
    end
    
    lib.registerContext({
        id = 'shop_main_menu',
        title = shopData.label,
        options = options
    })
    
    lib.showContext('shop_main_menu')
end

-- ショップ管理コマンドの登録
RegisterCommand('shopmanager', function()
    local isAdmin = lib.callback.await('ng-shop:server:isAdmin', false)
    if isAdmin then
        ShowShopLocationMenu()
    else
        lib.notify({type = 'error', description = '権限がありません'})
    end
end)

TriggerEvent('chat:addSuggestion', '/shopmanager', 'ショップ管理メニューを開く')

-- メインループ
CreateThread(function()
    Wait(1000) -- 初期化待ち
    RefreshShops() -- 初回のブリップ作成

    local cachedShops = {}

    -- ショップデータを定期的に更新（60秒ごと）
    CreateThread(function()
        while true do
            local shops = lib.callback.await('ng-shop:server:getShopLocations', false)
            if shops then
                cachedShops = shops
            end
            Wait(30000)
        end
    end)

    while true do
        local sleep = 1000
        local playerCoords = GetEntityCoords(PlayerPedId())
        
        for _, shop in pairs(cachedShops) do
            local shopCoords = vector3(shop.coords_x, shop.coords_y, shop.coords_z)
            local distance = #(playerCoords - shopCoords)
            
            if distance < 10.0 then
                sleep = 0
                DrawMarker(1,
                    shop.coords_x, shop.coords_y, shop.coords_z - 1.0,
                    0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0,
                    1.0, 1.0, 1.0,
                    0, 157, 255, 155,
                    false, false, 2, false, nil, nil, false
                )
                
                if distance < 1.5 and HasRequiredJob(shop) then
                    lib.showTextUI('[E] ショップを開く')
                    if IsControlJustReleased(0, 38) then
                        lib.hideTextUI()
                        ShowShopMenu(shop.shop_id, shop)
                    end
                else
                    lib.hideTextUI()
                end
            end
        end
        
        Wait(sleep)
    end
end)