Config = {}

-- コマンド設定
Config.Command = {
    name = 'satellite', -- コマンド名
    description = 'サテライトキャノンを発射', -- コマンドの説明
    permission = 'admin' -- 必要な権限（qb-core ranks）
}

-- サテライトキャノン設定
Config.Satellite = {
    cooldown = 30, -- クールダウン時間（秒）
    radius = 8.0, -- 爆発の半径
    damage = 1000, -- ダメージ量
    shake = 1.0, -- カメラシェイクの強さ
    maxDistance = 300.0, -- 最大射程距離
    effectDuration = 8000, -- エフェクトの持続時間（ミリ秒）
}

-- エフェクト設定
Config.Effects = {
    preEffect = "scr_xm_orbital_blast", -- 発射前のエフェクト
    mainEffect = "scr_xm_orbital_blast", -- メインのエフェクト
    effectLib = "scr_xm_orbital" -- エフェクトライブラリ
}

-- 通知メッセージ
Config.Messages = {
    cooldown = '⚠️ クールダウン中です。あと %s 秒お待ちください。',
    success = '🎯 サテライトキャノンを発射しました。',
    error = '❌ サテライトキャノンの発射に失敗しました。',
    outOfRange = '⚠️ 指定された位置が射程範囲外です。',
    noPermission = '⛔ このコマンドを使用する権限がありません。'
}