local QBCore = exports['qb-core']:GetCoreObject()

-- データベース初期化
local function InitializeDatabase()
    -- まずテーブルが存在するか確認
    local tableExists = MySQL.query.await([[
        SELECT COUNT(*) as count 
        FROM information_schema.tables 
        WHERE table_schema = DATABASE() 
        AND table_name = 'ng_invoices'
    ]])

    if tableExists[1].count == 0 then
        -- テーブルが存在しない場合は新規作成
        MySQL.query.await([[
            CREATE TABLE IF NOT EXISTS `ng_invoices` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `invoice_number` varchar(50) NOT NULL,
                `title` varchar(100) NOT NULL,
                `content` text NOT NULL,
                `sender_citizenid` varchar(50) NOT NULL,
                `sender_job` varchar(50) NOT NULL,
                `recipient_citizenid` varchar(50) NOT NULL,
                `total_amount` int(11) NOT NULL,
                `discount_rate` int NOT NULL DEFAULT 0,
                `is_personal` boolean NOT NULL DEFAULT FALSE,
                `status` enum('pending','paid','cancelled') NOT NULL DEFAULT 'pending',
                `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `paid_at` timestamp NULL DEFAULT NULL,
                PRIMARY KEY (`id`),
                KEY `sender_citizenid` (`sender_citizenid`),
                KEY `recipient_citizenid` (`recipient_citizenid`),
                KEY `status` (`status`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ]])
    else
        -- discount_rateカラムが存在するか確認
        local columnExists = MySQL.query.await([[
            SELECT COUNT(*) as count 
            FROM information_schema.columns 
            WHERE table_schema = DATABASE() 
            AND table_name = 'ng_invoices' 
            AND column_name = 'discount_rate'
        ]])

        if columnExists[1].count == 0 then
            -- discount_rateカラムが存在しない場合は追加
            MySQL.query.await([[
                ALTER TABLE `ng_invoices`
                ADD COLUMN `discount_rate` int NOT NULL DEFAULT 0 AFTER `total_amount`
            ]])
        end
    end
end

-- プレイヤーデータの取得
lib.callback.register('ng-invoice:getPlayerData', function(source, targetId)
    local Player = QBCore.Functions.GetPlayer(targetId)
    if not Player then return nil end

    return {
        firstname = Player.PlayerData.charinfo.firstname,
        lastname = Player.PlayerData.charinfo.lastname,
        citizenid = Player.PlayerData.citizenid
    }
end)

-- 権限チェック
RegisterNetEvent('ng-invoice:server:checkPermission', function()
    local src = source
    local hasPermission = IsPlayerAceAllowed(src, Config.AdminGroup)
    TriggerClientEvent('ng-invoice:client:permissionResponse', src, hasPermission)
end)

-- 請求書番号生成
local function GenerateInvoiceNumber()
    return string.format("INV-%s-%04d", 
        os.date("%Y%m%d"),
        math.random(1, 999999)
    )
end

-- 請求内容の検証
local function ValidateInvoiceContent(job, content, amount)
    local lines = {}
    for line in content:gmatch("[^\r\n]+") do
        table.insert(lines, line)
    end

    local totalAmount = 0
    for _, line in ipairs(lines) do
        local found = false
        local itemLabel = line:match("(.-): %$")
        if itemLabel then
            for _, preset in ipairs(Config.JobInvoicePresets[job]) do
                if preset.label == itemLabel then
                    totalAmount = totalAmount + preset.amount
                    found = true
                    break
                end
            end
            if not found then return false end
        end
    end

    return totalAmount == amount
end

lib.callback.register('ng-invoice:createInvoice', function(source, data)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return false end

    -- 金額が0以下の場合は作成不可
    if data.total_amount <= 0 then 
        TriggerClientEvent('QBCore:Notify', src, '無効な請求金額です', 'error')
        return false 
    end

    -- 請求書データの作成
    local invoiceData = {
        invoice_number = GenerateInvoiceNumber(),
        title = data.title,
        content = data.content,
        sender_citizenid = Player.PlayerData.citizenid,
        sender_job = Player.PlayerData.job.name,
        recipient_citizenid = data.recipient_citizenid,
        total_amount = data.total_amount,
        discount_rate = data.discount_rate or 0,  -- 新しく追加
        is_personal = data.is_personal,
        status = 'pending'
    }

    -- データベースに挿入
    local success = MySQL.insert.await('INSERT INTO ng_invoices SET ?', {invoiceData})
    if not success then return false end

    -- 受信者に通知
    local targetPlayer = QBCore.Functions.GetPlayerByCitizenId(data.recipient_citizenid)
    if targetPlayer then
        TriggerClientEvent('QBCore:Notify', targetPlayer.PlayerData.source, Config.Messages.invoice_received, 'info')
    end

    return true
end)

-- 職業口座への入金処理
local function AddJobMoney(jobName, amount, reason)
    if Config.BankingSystem == 'renewed' then
        -- Renewed-Banking用の処理
        local success = exports['qb-management']:AddMoney(jobName, amount)
        if success then
            print(string.format("Job payment successful - Job: %s, Amount: %s", jobName, amount))
            return true
        else
            print(string.format("Failed to add money to job account - Job: %s", jobName))
            return false
        end
    elseif Config.BankingSystem == 'qb-management' then
        -- qb-management用の処理
        exports['qb-management']:AddMoney(jobName, amount)
        return true
    elseif Config.BankingSystem == 'qb' then
        -- QB-Banking用の処理（既存のコード）
        local result = MySQL.single.await('SELECT id FROM bank_accounts WHERE account_name = ? AND account_type = ?', {jobName, 'job'})
        
        if result then
            MySQL.update.await('UPDATE bank_accounts SET account_balance = account_balance + ? WHERE id = ?', 
                {amount, result.id})
            MySQL.insert.await('INSERT INTO bank_statements (account_name, amount, reason, statement_type) VALUES (?, ?, ?, ?)',
                {jobName, amount, reason or "Invoice Payment", 'deposit'})
            return true
        end
    else
        -- okokBanking用の処理（既存のコード）
        local society = MySQL.single.await('SELECT * FROM '..Config.Database.okok.societies..' WHERE society = ?', {jobName})
        
        if society then
            MySQL.update.await('UPDATE '..Config.Database.okok.societies..' SET value = value + ? WHERE society = ?', 
                {amount, jobName})
            MySQL.insert.await('INSERT INTO '..Config.Database.okok.transactions..' (receiver_identifier, receiver_name, sender_identifier, sender_name, date, value, type) VALUES (?, ?, ?, ?, ?, ?, ?)',
                {
                    jobName,
                    society.society_name,
                    'SYSTEM',
                    'System',
                    os.date('%Y-%m-%d %H:%M:%S'),
                    amount,
                    'invoice_payment'
                })
            return true
        end
    end
    return false
end

-- 口座残高確認関数の追加
local function GetJobBalance(jobName)
    if Config.BankingSystem == 'renewed' then
        -- Renewed-Banking用
        return exports['qb-management']:GetAccount(jobName)
    elseif Config.BankingSystem == 'qb-management' then
        -- qb-management用
        return exports['qb-management']:GetAccount(jobName)
    elseif Config.BankingSystem == 'qb' then
        -- QB-Banking用
        local result = MySQL.single.await('SELECT account_balance FROM bank_accounts WHERE account_name = ? AND account_type = ?', {jobName, 'job'})
        return result and result.account_balance or 0
    else
        -- okokBanking用
        local result = MySQL.single.await('SELECT value FROM '..Config.Database.okok.societies..' WHERE society = ?', {jobName})
        return result and result.value or 0
    end
end

-- 請求書の支払い
lib.callback.register('ng-invoice:payInvoice', function(source, invoiceId, paymentType)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return false end

    -- 請求書の取得
    local invoice = MySQL.single.await('SELECT * FROM ng_invoices WHERE id = ? AND status = ?', 
        {invoiceId, 'pending'})
    if not invoice then return false end

    -- 支払い対象者の確認
    if invoice.recipient_citizenid ~= Player.PlayerData.citizenid then
        TriggerClientEvent('QBCore:Notify', src, '無効な請求書です', 'error')
        return false
    end

    -- 所持金チェック
    if Player.PlayerData.money[paymentType] < invoice.total_amount then
        TriggerClientEvent('QBCore:Notify', src, Config.Messages.not_enough_money, 'error')
        return false
    end

    -- 支払い処理
    Player.Functions.RemoveMoney(paymentType, invoice.total_amount, "invoice-payment")
    
    -- 請求者への入金処理
    local sender = QBCore.Functions.GetPlayerByCitizenId(invoice.sender_citizenid)
    
    -- ProcessPayment関数内の修正
    local function ProcessPayment(amount, jobName, citizenId, isOnline, isPersonal)
        if isPersonal then
            -- 個人請求の場合の処理（既存のコード）
            if isOnline then
                local sender = QBCore.Functions.GetPlayerByCitizenId(citizenId)
                if sender then
                    sender.Functions.AddMoney('bank', amount, "invoice-received")
                end
            else
                local result = MySQL.single.await('SELECT money FROM players WHERE citizenid = ?', {citizenId})
                if result and result.money then
                    local money = json.decode(result.money)
                    money.bank = money.bank + amount
                    MySQL.update.await('UPDATE players SET money = ? WHERE citizenid = ?', 
                        {json.encode(money), citizenId})
                end
            end
        else
            -- 職業による分配
            local ratio = Config.JobPaymentRatio[jobName] or 50
            local jobAmount = math.floor(amount * (ratio / 100))
            local personalAmount = amount - jobAmount
    
            -- 職業口座への入金
            AddJobMoney(jobName, jobAmount, "Invoice Payment")
    
            -- 個人口座への入金
            if isOnline then
                local sender = QBCore.Functions.GetPlayerByCitizenId(citizenId)
                if sender then
                    sender.Functions.AddMoney('bank', personalAmount, "invoice-received")
                end
            else
                local result = MySQL.single.await('SELECT money FROM players WHERE citizenid = ?', {citizenId})
                if result and result.money then
                    local money = json.decode(result.money)
                    money.bank = money.bank + personalAmount
                    MySQL.update.await('UPDATE players SET money = ? WHERE citizenid = ?', 
                        {json.encode(money), citizenId})
                end
            end
        end
    end

    -- 入金処理の実行
    ProcessPayment(
        invoice.total_amount, 
        invoice.sender_job, 
        invoice.sender_citizenid, 
        sender ~= nil, 
        invoice.is_personal
    )

    -- オンラインの請求者に通知
    if sender then
        TriggerClientEvent('QBCore:Notify', sender.PlayerData.source, "請求書の支払いを受け取りました", 'success')
    end

    -- 請求書の削除
    MySQL.query.await('DELETE FROM ng_invoices WHERE id = ?', {invoiceId})

    return true
end)

function IsPlayerBoss()
    local Player = PlayerData

    if not Player or not Player.job then 
        return {
            isBoss = false
        }
    end
   
    if Config.QBType == 'qbx' then
        return {
            isBoss = Player.job.isboss == true
        }
    else
        -- QBの場合、Shared.Jobsから該当のgradeを確認
        local job = QB.Shared.Jobs[Player.job.name]
        if job and job.grades then
            local gradeLevel = tostring(Player.job.grade.level)
            return {
                isBoss = job.grades[gradeLevel] and job.grades[gradeLevel].isboss == true
            }
        end
        return {
            isBoss = false
        }
    end
end

-- ボスメニュー用の請求書一覧取得
lib.callback.register('ng-invoice:getBossInvoices', function(source)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return {} end

    -- ボス権限チェック
    if not IsPlayerBoss(Player) then
        return {}
    end

    -- 該当ジョブの請求書を取得（collationを明示的に指定）
    local invoices = MySQL.query.await([[
        SELECT 
            i.id,
            i.invoice_number,
            i.title,
            i.content,
            i.sender_citizenid,
            i.sender_job,
            i.recipient_citizenid,
            i.total_amount,
            i.discount_rate,
            i.is_personal,
            i.status,
            DATE_FORMAT(i.created_at, '%Y年%m月%d日 %H:%i') as created_at,
            i.paid_at,
            CONCAT(
                COALESCE(JSON_UNQUOTE(JSON_EXTRACT(p.charinfo, '$.firstname')), '不明'), ' ',
                COALESCE(JSON_UNQUOTE(JSON_EXTRACT(p.charinfo, '$.lastname')), '')
            ) COLLATE utf8mb4_unicode_ci as recipient_name,
            CONCAT(
                COALESCE(JSON_UNQUOTE(JSON_EXTRACT(sp.charinfo, '$.firstname')), '不明'), ' ',
                COALESCE(JSON_UNQUOTE(JSON_EXTRACT(sp.charinfo, '$.lastname')), '')
            ) COLLATE utf8mb4_unicode_ci as sender_name
        FROM ng_invoices i
        LEFT JOIN players p ON p.citizenid COLLATE utf8mb4_unicode_ci = i.recipient_citizenid COLLATE utf8mb4_unicode_ci
        LEFT JOIN players sp ON sp.citizenid COLLATE utf8mb4_unicode_ci = i.sender_citizenid COLLATE utf8mb4_unicode_ci
        WHERE i.sender_job COLLATE utf8mb4_unicode_ci = ? COLLATE utf8mb4_unicode_ci
        ORDER BY i.created_at DESC
    ]], {Player.PlayerData.job.name})

    return invoices or {}
end)

-- 請求書の削除
lib.callback.register('ng-invoice:deleteInvoice', function(source, invoiceId)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return false end

    -- ボス権限チェック
    if not IsPlayerBoss(Player) then
        return false
    end

    -- 請求書の所有権確認
    local invoice = MySQL.single.await('SELECT sender_job FROM ng_invoices WHERE id = ?', {invoiceId})
    if not invoice or invoice.sender_job ~= Player.PlayerData.job.name then
        return false
    end

    -- 削除処理
    local success = MySQL.update.await('DELETE FROM ng_invoices WHERE id = ?', {invoiceId})
    return success ~= nil
end)

-- 強制執行処理
lib.callback.register('ng-invoice:forcePayment', function(source, invoiceId)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return false end
 
    -- ボス権限チェック
    if not IsPlayerBoss(Player) then
        return false, Config.Messages.no_permission
    end
 
    -- 強制執行権限の確認
    if not Config.ForcePaymentJobs[Player.PlayerData.job.name] then
        return false, Config.Messages.no_permission
    end
 
    -- 請求書の取得と確認
    local invoice = MySQL.single.await('SELECT * FROM ng_invoices WHERE id = ? AND status = ?', 
        {invoiceId, 'pending'})
    if not invoice or invoice.sender_job ~= Player.PlayerData.job.name then
        return false, '無効な請求書です'
    end
 
    -- 支払い対象者の所持金確認
    local targetPlayer = QBCore.Functions.GetPlayerByCitizenId(invoice.recipient_citizenid)
    
    -- 金額の引き落とし処理
    local function deductMoney(accountType, amount)
        if targetPlayer then
            -- オンラインプレイヤーの場合
            targetPlayer.Functions.RemoveMoney(accountType, amount, "forced-invoice-payment")
        else
            -- オフラインプレイヤーの場合
            local result = MySQL.single.await('SELECT money FROM players WHERE citizenid = ?', {invoice.recipient_citizenid})
            if result and result.money then
                local money = json.decode(result.money)
                money[accountType] = (money[accountType] or 0) - amount
                MySQL.update.await('UPDATE players SET money = ? WHERE citizenid = ?', 
                    {json.encode(money), invoice.recipient_citizenid})
            end
        end
    end
 
    -- 残高チェックとマイナス処理
    if targetPlayer then
        -- オンラインプレイヤーの場合
        if Config.ForcePayment.allowNegativeBalance then
            -- マイナス残高を許可する場合は全額を銀行から引き落とし
            deductMoney('bank', invoice.total_amount)
        else
            -- マイナス残高を許可しない場合は残高チェック
            if (targetPlayer.PlayerData.money.bank + targetPlayer.PlayerData.money.cash) < invoice.total_amount then
                return false, Config.Messages.insufficient_funds
            end
            
            -- 銀行残高から可能な限り引き落とし
            local bankAmount = math.min(targetPlayer.PlayerData.money.bank, invoice.total_amount)
            if bankAmount > 0 then
                deductMoney('bank', bankAmount)
            end
            
            -- 残額を現金から引き落とし
            local remainingAmount = invoice.total_amount - bankAmount
            if remainingAmount > 0 then
                deductMoney('cash', remainingAmount)
            end
        end
    else
        -- オフラインプレイヤーの場合
        local result = MySQL.single.await('SELECT money FROM players WHERE citizenid = ?', {invoice.recipient_citizenid})
        if result and result.money then
            local money = json.decode(result.money)
            if Config.ForcePayment.allowNegativeBalance then
                -- マイナス残高を許可する場合は全額を銀行から引き落とし
                money.bank = (money.bank or 0) - invoice.total_amount
                MySQL.update.await('UPDATE players SET money = ? WHERE citizenid = ?', 
                    {json.encode(money), invoice.recipient_citizenid})
            else
                -- マイナス残高を許可しない場合は残高チェック
                local totalMoney = (money.bank or 0) + (money.cash or 0)
                if totalMoney < invoice.total_amount then
                    return false, Config.Messages.insufficient_funds
                end
                
                -- 銀行残高から可能な限り引き落とし
                local bankAmount = math.min(money.bank or 0, invoice.total_amount)
                if bankAmount > 0 then
                    money.bank = (money.bank or 0) - bankAmount
                end
                
                -- 残額を現金から引き落とし
                local remainingAmount = invoice.total_amount - bankAmount
                if remainingAmount > 0 then
                    money.cash = (money.cash or 0) - remainingAmount
                end
                
                MySQL.update.await('UPDATE players SET money = ? WHERE citizenid = ?', 
                    {json.encode(money), invoice.recipient_citizenid})
            end
        end
    end
 
    -- 職業口座への入金と送信者への支払い処理
    if invoice.is_personal then
        -- 個人請求の場合、全額を送信者の個人口座へ
        local sender = QBCore.Functions.GetPlayerByCitizenId(invoice.sender_citizenid)
        if sender then
            -- オンラインの場合
            sender.Functions.AddMoney('bank', invoice.total_amount, "forced-invoice-received")
        else
            -- オフラインの場合
            local result = MySQL.single.await('SELECT money FROM players WHERE citizenid = ?', {invoice.sender_citizenid})
            if result and result.money then
                local money = json.decode(result.money)
                money.bank = (money.bank or 0) + invoice.total_amount
                MySQL.update.await('UPDATE players SET money = ? WHERE citizenid = ?', 
                    {json.encode(money), invoice.sender_citizenid})
            end
        end
    else
        -- 職業による分配
        local ratio = Config.JobPaymentRatio[invoice.sender_job] or 50 -- デフォルトは50%
        local jobAmount = math.floor(invoice.total_amount * (ratio / 100))
        local personalAmount = invoice.total_amount - jobAmount
 
        -- 職業口座への入金
        AddJobMoney(invoice.sender_job, jobAmount, "Forced Invoice Payment")
 
        -- 送信者への個人支払い
        local sender = QBCore.Functions.GetPlayerByCitizenId(invoice.sender_citizenid)
        if sender then
            -- オンラインの場合
            sender.Functions.AddMoney('bank', personalAmount, "forced-invoice-received")
        else
            -- オフラインの場合
            local result = MySQL.single.await('SELECT money FROM players WHERE citizenid = ?', {invoice.sender_citizenid})
            if result and result.money then
                local money = json.decode(result.money)
                money.bank = (money.bank or 0) + personalAmount
                MySQL.update.await('UPDATE players SET money = ? WHERE citizenid = ?', 
                    {json.encode(money), invoice.sender_citizenid})
            end
        end
    end
 
    -- 請求書の削除（更新ではなく削除に変更）
    MySQL.query.await('DELETE FROM ng_invoices WHERE id = ?', {invoiceId})
 
    -- 処理完了通知
    if targetPlayer then
        TriggerClientEvent('QBCore:Notify', targetPlayer.PlayerData.source, '請求書が強制執行されました', 'error')
    end
 
    return true, Config.Messages.force_payment_success
 end)

-- 請求書一覧取得（送信者情報付き）
lib.callback.register('ng-invoice:getInvoices', function(source, type)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return {} end

    local citizenid = Player.PlayerData.citizenid

    -- 請求書を取得（JOINを使用して1回のクエリで情報を取得）
    local invoices = MySQL.query.await([[
        SELECT 
            i.*,
            DATE_FORMAT(i.created_at, '%Y年%m月%d日 %H:%i') as created_at,
            CONCAT(
                COALESCE(JSON_UNQUOTE(JSON_EXTRACT(p.charinfo, '$.firstname')), '不明'), ' ',
                COALESCE(JSON_UNQUOTE(JSON_EXTRACT(p.charinfo, '$.lastname')), '')
            ) COLLATE utf8mb4_unicode_ci as sender_name
        FROM ng_invoices i
        LEFT JOIN players p ON p.citizenid COLLATE utf8mb4_unicode_ci = i.sender_citizenid COLLATE utf8mb4_unicode_ci
        WHERE i.recipient_citizenid = ? 
        AND i.status = 'pending'
        ORDER BY i.created_at DESC
    ]], {citizenid})

    if not invoices then return {} end

    return invoices
end)

-- デバッグ用：リソース起動時にメッセージを表示
CreateThread(function()
    print('Invoice system callbacks registered')
end)

-- リソース起動時の初期化
CreateThread(function()
    InitializeDatabase()
end)