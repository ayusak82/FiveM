local QBCore = exports['qb-core']:GetCoreObject()
local playerVisibility = {}

-- テーブル作成
MySQL.ready(function()
    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS `nameplate_settings` (
            `citizenid` varchar(50) NOT NULL,
            `visibility` boolean DEFAULT true,
            `streamer_mode` boolean DEFAULT false,
            `nickname` varchar(50) DEFAULT NULL,
            `use_nickname` boolean DEFAULT false,
            `top_text` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
            `use_top_text` boolean DEFAULT false,
            `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`citizenid`)
        )
    ]])
end)

local function GetPlayerSettings(citizenid)
    local result = MySQL.query.await('SELECT * FROM nameplate_settings WHERE citizenid = ?', {
        citizenid
    })
    
    if not result or not result[1] then
        return false
    end
    return result[1]
end

local function UpdatePlayerSettings(citizenid, settings)
    -- デバッグ用のプリント
    print('Updating settings for:', citizenid)
    print('Settings before:', json.encode(settings))

    -- boolean値を明示的に設定
    local params = {
        citizenid,                              -- 1
        settings.visibility == true,            -- 2
        settings.streamerMode == true,          -- 3
        settings.nickname,                      -- 4
        settings.useNickname == true,           -- 5
        settings.topText,                       -- 6
        settings.useTopText == true             -- 7
    }

    print('Parameters:', json.encode(params))

    local success = MySQL.query.await([[
        INSERT INTO nameplate_settings 
        (citizenid, visibility, streamer_mode, nickname, use_nickname, top_text, use_top_text) 
        VALUES (?, ?, ?, ?, ?, ?, ?) 
        ON DUPLICATE KEY UPDATE 
        visibility = ?,
        streamer_mode = ?,
        nickname = ?,
        use_nickname = ?,
        top_text = ?,
        use_top_text = ?
    ]], {
        -- INSERT用パラメータ
        params[1], params[2], params[3], params[4], params[5], params[6], params[7],
        -- UPDATE用パラメータ
        params[2], params[3], params[4], params[5], params[6], params[7]
    })

    print('Update result:', success)
    
    -- 更新後の設定を確認
    local verifySettings = GetPlayerSettings(citizenid)
    print('Settings after:', json.encode(verifySettings))
end

-- ニックネーム更新イベント
RegisterNetEvent('ng-name:server:updateNickname', function(nickname)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if Player then
        if #nickname < Config.Nickname.minLength or #nickname > Config.Nickname.maxLength then
            TriggerClientEvent('ox_lib:notify', src, {
                title = 'エラー',
                description = string.format('ニックネームは%d-%d文字で設定してください', Config.Nickname.minLength, Config.Nickname.maxLength),
                type = 'error'
            })
            return
        end

        -- 現在の設定を取得
        local currentSettings = GetPlayerSettings(Player.PlayerData.citizenid) or {}
        
        -- 現在の設定を全て維持しながら、nicknameのみを更新
        local settings = {
            visibility = currentSettings.visibility,
            streamerMode = currentSettings.streamer_mode,
            nickname = nickname,                        -- これのみ更新
            useNickname = currentSettings.use_nickname,
            topText = currentSettings.top_text,
            useTopText = currentSettings.use_top_text
        }
        
        print('Updating nickname:', nickname)           -- デバッグ用
        print('Current settings:', json.encode(settings)) -- デバッグ用
        
        UpdatePlayerSettings(Player.PlayerData.citizenid, settings)
        TriggerClientEvent('ng-name:client:syncNickname', -1, src, nickname)
    end
end)

RegisterNetEvent('ng-name:server:toggleNickname', function(useNickname)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if Player then
        -- 現在の設定を取得
        local currentSettings = GetPlayerSettings(Player.PlayerData.citizenid) or {}
        
        -- 現在の設定を全て維持しながら、useNicknameのみを更新
        local settings = {
            visibility = currentSettings.visibility,
            streamerMode = currentSettings.streamer_mode,
            nickname = currentSettings.nickname,
            useNickname = useNickname,                  -- これのみ更新
            topText = currentSettings.top_text,
            useTopText = currentSettings.use_top_text
        }
        
        print('Updating nickname usage:', useNickname)    -- デバッグ用
        print('Current settings:', json.encode(settings)) -- デバッグ用
        
        UpdatePlayerSettings(Player.PlayerData.citizenid, settings)
        TriggerClientEvent('ng-name:client:syncNicknameToggle', -1, src, useNickname)
    end
end)

-- 上部テキスト更新イベント
RegisterNetEvent('ng-name:server:updateTopText', function(text)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if Player then
        if #text < Config.TopText.minLength or #text > Config.TopText.maxLength then
            TriggerClientEvent('ox_lib:notify', src, {
                title = 'エラー',
                description = string.format('上部テキストは%d-%d文字で設定してください', Config.TopText.minLength, Config.TopText.maxLength),
                type = 'error'
            })
            return
        end

        local settings = GetPlayerSettings(Player.PlayerData.citizenid) or {}
        settings.topText = text
        settings.visibility = settings.visibility or true
        settings.streamerMode = settings.streamer_mode or false
        settings.nickname = settings.nickname
        settings.useNickname = settings.use_nickname or false
        settings.useTopText = settings.use_top_text or true
        
        UpdatePlayerSettings(Player.PlayerData.citizenid, settings)
        TriggerClientEvent('ng-name:client:syncTopText', -1, src, text)
    end
end)

-- 上部テキスト表示切替イベント
RegisterNetEvent('ng-name:server:toggleTopText', function(useTopText)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if Player then
        local settings = GetPlayerSettings(Player.PlayerData.citizenid) or {}
        settings.useTopText = useTopText
        settings.visibility = settings.visibility or true
        settings.streamerMode = settings.streamer_mode or false
        settings.nickname = settings.nickname
        settings.useNickname = settings.use_nickname or false
        settings.topText = settings.top_text
        
        UpdatePlayerSettings(Player.PlayerData.citizenid, settings)
        TriggerClientEvent('ng-name:client:syncTopTextToggle', -1, src, useTopText)
    end
end)

-- プレイヤー接続時の処理
RegisterNetEvent('QBCore:Server:PlayerLoaded', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if Player then
        local settings = GetPlayerSettings(Player.PlayerData.citizenid)
        if settings then
            playerVisibility[src] = settings.visibility
            TriggerClientEvent('ng-name:client:loadSettings', src, 
                settings.visibility, 
                settings.streamer_mode, 
                settings.nickname, 
                settings.use_nickname,
                settings.top_text,    -- 追加
                settings.use_top_text -- 追加
            )
        else
            UpdatePlayerSettings(Player.PlayerData.citizenid, {
                visibility = true,
                streamerMode = false,
                nickname = nil,
                useNickname = false,
                topText = nil,      -- 追加
                useTopText = false  -- 追加
            })
            playerVisibility[src] = true
            TriggerClientEvent('ng-name:client:loadSettings', src, true, false, nil, false, nil, false)
        end
    end
end)

-- 配信者モードの更新イベント
RegisterNetEvent('ng-name:server:updateStreamerMode', function(enabled)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if Player then
        local currentSettings = GetPlayerSettings(Player.PlayerData.citizenid) or {}
        
        -- 現在の設定を全て維持しながら、streamerModeのみを更新
        local settings = {
            visibility = currentSettings.visibility,
            streamerMode = enabled,                      -- これのみ更新
            nickname = currentSettings.nickname,
            useNickname = currentSettings.use_nickname,
            topText = currentSettings.top_text,
            useTopText = currentSettings.use_top_text
        }
        
        print('Updating streamer mode:', enabled)        -- デバッグ用
        print('Current settings:', json.encode(settings)) -- デバッグ用
        
        UpdatePlayerSettings(Player.PlayerData.citizenid, settings)
        TriggerClientEvent('ng-name:client:syncStreamerMode', -1, src, enabled)
    end
end)

RegisterNetEvent('ng-name:server:updateVisibility', function(isVisible)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if Player then
        -- 現在の設定を取得
        local currentSettings = GetPlayerSettings(Player.PlayerData.citizenid) or {}
        
        -- 設定を更新（他の設定はそのまま維持）
        local settings = {
            visibility = isVisible,
            streamerMode = currentSettings.streamer_mode,        -- 変換せずそのまま
            nickname = currentSettings.nickname,
            useNickname = currentSettings.use_nickname,          -- 変換せずそのまま
            topText = currentSettings.top_text,
            useTopText = currentSettings.use_top_text           -- 変換せずそのまま
        }
        
        print('Current settings:', json.encode(currentSettings))  -- デバッグ用
        print('New settings:', json.encode(settings))            -- デバッグ用
        
        UpdatePlayerSettings(Player.PlayerData.citizenid, settings)
        playerVisibility[src] = isVisible
        
        if isVisible then
            local charInfo = Player.PlayerData.charinfo
            TriggerClientEvent('ng-name:client:displayName', -1, src, 
                charInfo.firstname, 
                charInfo.lastname, 
                settings.nickname, 
                settings.useNickname, 
                settings.streamerMode,
                settings.topText,
                settings.useTopText
            )
        end
        
        TriggerClientEvent('ng-name:client:syncVisibility', -1, src, isVisible)
        TriggerClientEvent('ng-name:client:loadSettings', src, 
            isVisible, 
            settings.streamerMode, 
            settings.nickname, 
            settings.useNickname,
            settings.topText,
            settings.useTopText
        )
    end
end)

-- プレイヤー名取得イベントの修正
RegisterNetEvent('ng-name:server:getPlayerName', function(targetId)
    local src = source
    local Player = QBCore.Functions.GetPlayer(targetId)
    
    if Player then
        local charInfo = Player.PlayerData.charinfo
        local settings = GetPlayerSettings(Player.PlayerData.citizenid) or {}
        
        -- キャッシュの可視性状態を更新
        playerVisibility[targetId] = settings.visibility

        -- 全ての設定を送信（上部テキスト情報を追加）
        TriggerClientEvent('ng-name:client:displayName', src, targetId, 
            charInfo.firstname, 
            charInfo.lastname, 
            settings.nickname,
            settings.use_nickname,
            settings.streamer_mode,
            settings.top_text,
            settings.use_top_text
        )

        -- 自分自身の場合は設定も更新
        if src == targetId then
            TriggerClientEvent('ng-name:client:loadSettings', src,
                settings.visibility,
                settings.streamer_mode,
                settings.nickname,
                settings.use_nickname,
                settings.top_text,
                settings.use_top_text
            )
        end
    end
end)

-- プレイヤー切断時の処理
AddEventHandler('playerDropped', function()
    local src = source
    playerVisibility[src] = nil
end)

-- スクリプト起動時のデバッグメッセージ
AddEventHandler('onResourceStart', function(resourceName)
    if (GetCurrentResourceName() ~= resourceName) then
        return
    end
    print('^2ng-name^7: スクリプトが正常に起動しました')
end)

-- スクリプト停止時のデバッグメッセージ
AddEventHandler('onResourceStop', function(resourceName)
    if (GetCurrentResourceName() ~= resourceName) then
        return
    end
    print('^2ng-name^7: スクリプトが停止しました')
end)