Config = {}

-- Discord Webhook URL("https://discord.webhook") または false
Config.Webhook = false

-- UI表示キー設定
Config.OpenKey = 'F7'

-- ace権限設定
Config.AdminGroup = 'group.admin'

-- バンキングシステム設定
-- 'renewed' : Renewed-Banking
-- 'qb' : QB-Banking
-- 'okok' : okokBanking
-- 'qb-management' : qb-management
Config.BankingSystem = ''

-- QBCoreの種類設定
-- 'qb' または 'qbx'
Config.QBType = ''

-- データベーステーブル設定
Config.Database = {
    renewed = {
        accounts = 'bank_accounts_new',
        transactions = 'player_transactions'
    },
    ['qb-management'] = {
        accounts = 'management_funds',
        type = 'boss'
    },
    qb = {
        accounts = 'bank_accounts',
        statements = 'bank_statements'
    },
    okok = {
        transactions = 'okokbanking_transactions',
        societies = 'okokbanking_societies'
    }
}

-- 強制執行が可能な職業リスト
Config.ForcePaymentJobs = {
    ['police'] = true,
    ['ambulance'] = true,
}

-- 強制執行の設定
Config.ForcePayment = {
    allowNegativeBalance = false, -- trueの場合、残高がマイナスになることを許可
    checkAccounts = {  -- 残高チェック対象の口座タイプ
        bank = true,   -- 銀行口座
        cash = true    -- 現金所持
    }
}

-- プリセット請求を使用できる職業リスト（その他の職業はその他の金額のみ使用可能）
Config.JobList = {
    ['police'] = true,
    ['ambulance'] = true,
    ['mechanic'] = true,
}

-- 職業ごとの収入分配率設定（%） - 設定された%が職業口座に入金
Config.JobPaymentRatio = {
    ['police'] = 70,     -- 70%が職業口座、30%が個人の手持ち
    ['ambulance'] = 80,  -- 80%が職業口座、20%が個人の手持ち
    ['mechanic'] = 60,   -- 60%が職業口座、40%が個人の手持ち
}

-- 職業ごとの請求内容プリセット
Config.JobInvoicePresets = {
    ['police'] = {
        {label = '速度超過', amount = 1500},
        {label = '信号無視', amount = 2000},
        {label = '危険運転', amount = 3000},
        {label = '無免許運転', amount = 5000},
        {label = '器物損壊', amount = 5000},
        {label = '暴行罪', amount = 7500},
        {label = '強盗罪', amount = 10000},
        {label = '殺人罪', amount = 15000},
    },
    ['mechanic'] = {
        {label = '基本点検', amount = 500},
        {label = 'オイル交換', amount = 1000},
        {label = '部品交換', amount = 2500},
        {label = 'エンジン修理', amount = 4000},
        {label = '大規模修理', amount = 5000},
    },
    ['ambulance'] = {
        {label = '応急処置', amount = 1000},
        {label = '診察料', amount = 2000},
        {label = '入院費', amount = 5000},
        {label = '手術費', amount = 10000},
    }
}

-- メッセージ設定
Config.Messages = {
    invoice_created = '請求書を作成しました',
    invoice_received = '新しい請求書を受け取りました',
    invoice_paid = '請求書の支払いが完了しました',
    invoice_cancelled = '請求書をキャンセルしました',
    not_enough_money = '所持金が不足しています',
    invalid_target = '無効な請求先です',
    no_permission = '権限がありません',
    insufficient_funds = '対象者の所持金が不足しているため強制執行できません',
    force_payment_success = '強制執行が完了しました',
    force_payment_failed = '強制執行に失敗しました'
}

return Config