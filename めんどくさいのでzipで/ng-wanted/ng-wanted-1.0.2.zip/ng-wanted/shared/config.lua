Config = {}

-- 指名手配可能な最大時間（分）
Config.MaxWantedTime = 60

-- 罪名リスト
Config.Crimes = {
    { label = '殺人', fine = 10000 },
    { label = '強盗', fine = 8000 },
    { label = '暴行', fine = 5000 },
    { label = '薬物所持', fine = 4000 },
    { label = '薬物取引', fine = 7000 },
    { label = '違法武器所持', fine = 6000 },
    { label = '誘拐', fine = 9000 },
    { label = '公務執行妨害', fine = 3000 },
    { label = '逃走', fine = 2000 },
    { label = '銀行強盗', fine = 15000 },
    { label = '危険運転', fine = 2500 },
    { label = '侵入', fine = 3500 },
    { label = '詐欺', fine = 4500 },
    { label = '公共物損壊', fine = 1500 }
}

-- 指名手配を利用できるジョブ
Config.AllowedJobs = {
    ['police'] = true,
    ['sheriff'] = true
}

-- 一般市民用の指名手配リスト閲覧を許可するかどうか
Config.AllowCivilianAccess = true

-- UIの設定
Config.UI = {
    title = "指名手配システム",
    civilian_title = "指名手配情報"
}

-- 通知の設定
Config.Notification = {
    enable = true,
    soundType = "native", -- 通知音タイプ: "native" / "mp3" / "qbcore"
    
    -- ネイティブサウンド設定
    nativeSound = {
        sound = "Beep_Red",
        soundSet = "DLC_HEIST_HACKING_SNAKE_SOUNDS"
    },
    
    -- MP3サウンド設定
    mp3Sound = {
        file = "wanted.mp3", -- ui/sounds/フォルダ内のファイル名
        volume = 0.5 -- 0.0 ~ 1.0
    },
    
    -- QBCore通知設定
    qbcoreNotification = {
        type = "警告", -- 通知タイプ
        duration = 15000 -- 表示時間(ミリ秒)
    }
}

-- データベースの設定
Config.DatabaseTable = "wanted_criminals"
