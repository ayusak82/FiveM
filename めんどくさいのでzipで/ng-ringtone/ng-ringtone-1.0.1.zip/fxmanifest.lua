fx_version 'cerulean'
game 'gta5'

author 'NCCGr'
description 'LB-Phone用のリングトーン変更アプリ'
version '1.0.0'

client_scripts {
    'client/main.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua'
}

lua54 'yes'

file "ui/dist/**/*"

ui_page "ui/dist/index.html"

dependencies {
    'qb-core',
    'lb-phone',
    'xsound',
    'oxmysql'
}