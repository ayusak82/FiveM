local QBCore = exports['qb-core']:GetCoreObject()
local isUIOpen = false

-- プレイヤーデータ
local PlayerData = {}
local citizenId = nil

-- イベントとして登録
RegisterNetEvent('ng-fishing-ranking:client:openMenu')
AddEventHandler('ng-fishing-ranking:client:openMenu', function()
    TriggerServerEvent('ng-fishing-ranking:server:openRanking')
end)

-- メニュー項目の取得用export
exports('GetMenuItem', function()
    return {
        id = 'fishing_ranking',
        icon = 'trophy',
        label = '釣りランキング',
        event = 'ng-fishing-ranking:client:openMenu',
    }
end)

-- UI表示関数
local function OpenRankingUI(data)
    if isUIOpen then return end
    isUIOpen = true
    
    SetNuiFocus(true, true)
    
    SendNUIMessage({
        action = 'open',
        citizenId = citizenId,
        experienceRankings = data.experienceRankings,
        catchRankings = data.catchRankings,
        playerRank = data.playerRank,
        playerExp = data.playerExp
    })
end

-- UI閉じる関数
local function CloseRankingUI()
    if not isUIOpen then return end
    isUIOpen = false
    
    SetNuiFocus(false, false)
    
    SendNUIMessage({
        action = 'close'
    })
end

-- コールバック関数
RegisterNUICallback('closeUI', function(data, cb)
    CloseRankingUI()
    cb('ok')
end)

-- コマンド登録
RegisterCommand(Config.OpenCommand, function()
    -- 職業制限がある場合はチェック
    if Config.AllowedJobs and not Config.AllowedJobs[PlayerData.job.name] then
        QBCore.Functions.Notify('このコマンドを使用する権限がありません', 'error')
        return
    end
    
    TriggerServerEvent('ng-fishing-ranking:server:openRanking')
end, false)

-- キー割り当て（オプション）
-- RegisterKeyMapping(Config.OpenCommand, '釣りランキングを開く', 'keyboard', 'F9')

-- イベントリスナー
RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    PlayerData = QBCore.Functions.GetPlayerData()
    citizenId = PlayerData.citizenid
end)

RegisterNetEvent('QBCore:Client:OnJobUpdate', function(JobInfo)
    PlayerData.job = JobInfo
end)

RegisterNetEvent('ng-fishing-ranking:client:openRanking', function(data)
    OpenRankingUI(data)
end)

RegisterNetEvent('ng-fishing-ranking:client:updateRankings', function(type, rankings)
    if isUIOpen then
        SendNUIMessage({
            action = 'updateRankings',
            type = type,
            rankings = rankings
        })
    end
end)

-- リソース開始時の処理
AddEventHandler('onResourceStart', function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end
    
    PlayerData = QBCore.Functions.GetPlayerData()
    citizenId = PlayerData.citizenid
end)

-- ESCキーでUI閉じる
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if isUIOpen and IsControlJustReleased(0, 177) then -- 177 = ESCAPE key
            CloseRankingUI()
        end
    end
end)