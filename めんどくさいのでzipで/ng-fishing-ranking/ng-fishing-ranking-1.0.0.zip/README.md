# 釣りランキングシステム / Fishing Ranking System

## 概要 / Overview

このスクリプトはGTA5のFiveM向けに開発された釣りのランキングシステムです。プレイヤーの釣り経験値に基づいてサーバー内でのランキングを表示します。

This script is a fishing ranking system developed for FiveM in GTA5. It displays server-wide rankings based on players' fishing experience.

## 機能 / Features

- 経験値に基づく釣りランキングの表示
- 上位10名のプレイヤーをリストアップ
- 自分の順位と経験値の確認
- コマンドによる簡単なアクセス
- 美しいUIデザイン（日本語対応）
- メダル表示（1位🥇、2位🥈、3位🥉）
- 自分の順位がハイライト表示

## 必要条件 / Dependencies

- [qb-core](https://github.com/qbcore-framework/qb-core) - QBCoreフレームワーク
- [ox_lib](https://github.com/overextended/ox_lib) - Ox Libライブラリ
- [oxmysql](https://github.com/overextended/oxmysql) - MySQL接続用

## インストール方法 / Installation

1. このリソースをサーバーの `resources` フォルダにコピーします。
2. サーバーの `server.cfg` に以下の行を追加します：
   ```
   ensure ng-fishing-ranking
   ```
3. サーバーを再起動します。

## 使用方法 / Usage

### コマンド / Commands

- `/fishranking` - ランキング画面を開く

## 設定 / Configuration

`shared/config.lua` ファイルで以下の設定が可能です：

```lua
Config = {}

-- ランキング設定
Config.RankingLimit = 10 -- 表示するランキング数
Config.RefreshTime = 300 -- ランキング更新間隔（秒）

-- UI設定
Config.OpenCommand = 'fishranking' -- ランキングを開くコマンド
Config.AllowedJobs = nil -- 特定の職業のみ閲覧可能にする場合は設定する ('police', 'ambulance' など)

-- デバッグモード
Config.Debug = false
```

## データベース / Database

スクリプトは自動的に必要なデータベーステーブルを作成します：

```sql
CREATE TABLE IF NOT EXISTS m_fishing (
    citizenid VARCHAR(50) PRIMARY KEY,
    experience INT DEFAULT 0
)
```

## 開発者向け情報 / Developer Information

### エクスポート / Exports

メニュー項目として他のリソースに組み込むことが可能です：

```lua
exports['ng-fishing-ranking']:GetMenuItem()
```

これにより以下の情報を取得できます：

```lua
{
    id = 'fishing_ranking',
    icon = 'trophy',
    label = '釣りランキング',
    event = 'ng-fishing-ranking:client:openMenu',
}
```

### デバッグ / Debug

`Config.Debug = true` に設定すると、以下のデバッグコマンドが使用可能になります：

- `/testrankingdata` - テストデータを追加（管理者のみ）

## クレジット / Credits

作成者: NCCGr

## ライセンス / License

All Rights Reserved.

このスクリプトの無断転載、再配布、改変は禁止されています。
Unauthorized reproduction, redistribution, or modification of this script is prohibited.