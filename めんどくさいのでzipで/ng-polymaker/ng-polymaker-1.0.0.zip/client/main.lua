local QBCore = exports['qb-core']:GetCoreObject()
local points = {}
local isCreating = false

-- キーマッピング用の定数
local KEYS = {
    ['E'] = 38,
    ['X'] = 73,
    ['ENTER'] = 191,
    ['ESC'] = 322
}

-- ポイント追加関数
local function AddPoint()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    table.insert(points, vector2(coords.x, coords.y))
    lib.notify({
        title = 'ポイント追加',
        description = string.format('X: %.2f, Y: %.2f', coords.x, coords.y),
        type = 'success'
    })
end

-- 最後のポイント削除関数
local function RemoveLastPoint()
    if #points > 0 then
        table.remove(points)
        lib.notify({
            title = 'ポイント削除',
            description = '最後のポイントを削除しました',
            type = 'info'
        })
    end
end

-- ポイントをクリップボードにコピー
local function CopyToClipboard()
    if #points == 0 then
        lib.notify({
            title = 'エラー',
            description = Config.Text.noPoints,
            type = 'error'
        })
        return
    end

    local text = ""
    for i, point in ipairs(points) do
        text = text .. string.format("vector2(%.2f, %.2f)", point.x, point.y)
        if i < #points then
            text = text .. ",\n"
        end
    end

    lib.setClipboard(text)
    lib.notify({
        title = 'コピー完了',
        description = Config.Text.copied,
        type = 'success'
    })
end

-- キー入力の監視
local function HandleKeypress()
    if IsControlJustPressed(0, KEYS[Config.Keys.addPoint]) then
        AddPoint()
    elseif IsControlJustPressed(0, KEYS[Config.Keys.removePoint]) then
        RemoveLastPoint()
    elseif IsControlJustPressed(0, KEYS[Config.Keys.finish]) then
        CopyToClipboard()
        isCreating = false
        lib.hideTextUI()
    elseif IsControlJustPressed(0, KEYS[Config.Keys.cancel]) then
        points = {}
        isCreating = false
        lib.hideTextUI()
        lib.notify({
            title = 'キャンセル',
            description = Config.Text.cancelled,
            type = 'error'
        })
    end
end

-- ポイントの描画
local function DrawPoints()
    for i, point in ipairs(points) do
        DrawMarker(1, point.x, point.y, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 255, 0, 0, 100, false, true, 2, false, nil, nil, false)
        
        -- ポイント間の線を描画
        if i < #points then
            local nextPoint = points[i + 1]
            DrawLine(point.x, point.y, 0.0, nextPoint.x, nextPoint.y, 0.0, 255, 0, 0, 255)
        end
        
        -- 最後のポイントと最初のポイントを結ぶ線を描画（ポリゴンを閉じる）
        if i == #points and #points > 2 then
            local firstPoint = points[1]
            DrawLine(point.x, point.y, 0.0, firstPoint.x, firstPoint.y, 0.0, 255, 0, 0, 255)
        end
    end
end

-- 操作説明の表示
local function ShowInstructions()
    lib.showTextUI('[E] ポイントを追加\n\n[X] 前のポイントを削除\n\n[ENTER] 完了\n\n[ESC] キャンセル', {
        position = "top-center",
        style = {
            borderRadius = 0,
            backgroundColor = '#1A1A1A',
            color = 'white'
        }
    })
end

-- メインループ
CreateThread(function()
    while true do
        if isCreating then
            HandleKeypress()
            DrawPoints()
        end
        Wait(0)
    end
end)

-- コマンドの登録
RegisterCommand(Config.Command.name, function()
    points = {}
    isCreating = true
    ShowInstructions()
    lib.notify({
        title = 'ポリゾーン作成開始',
        description = 'ポイントを設定してください',
        type = 'info'
    })
end, false)

TriggerEvent('chat:addSuggestion', '/' .. Config.Command.name, Config.Command.description)