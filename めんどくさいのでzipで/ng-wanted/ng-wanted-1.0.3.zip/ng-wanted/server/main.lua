local QBCore = exports['qb-core']:GetCoreObject()

-- Create database table
CreateThread(function()
    MySQL.Async.execute([[
        CREATE TABLE IF NOT EXISTS ]]..Config.DatabaseTable..[[ (
            id INT AUTO_INCREMENT PRIMARY KEY,
            criminal_name VARCHAR(255) NOT NULL,
            crimes TEXT NOT NULL,
            fine INT NOT NULL,
            wanted_until TIMESTAMP NOT NULL,
            added_by VARCHAR(50) NOT NULL,
            added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ]], {})
end)

-- Get wanted list callback
QBCore.Functions.CreateCallback('ng-wanted:server:getWantedList', function(source, cb)
    MySQL.Async.fetchAll('SELECT * FROM '..Config.DatabaseTable..' WHERE wanted_until > NOW()', {}, function(result)
        if result and type(result) == "table" then
            -- Convert crime strings to tables
            for i=1, #result do
                if result[i].crimes then
                    result[i].crimes = json.decode(result[i].crimes)
                else
                    result[i].crimes = {}
                end
            end
            cb(result)
        else
            cb({})
        end
    end)
end)

-- Get players list callback
QBCore.Functions.CreateCallback('ng-wanted:server:getPlayers', function(source, cb)
    local players = {}
    local src = source
    local srcPlayer = QBCore.Functions.GetPlayer(src)
    
    if not srcPlayer then return cb({}) end
    
    -- Only police jobs can access
    if not Config.AllowedJobs[srcPlayer.PlayerData.job.name] then
        return cb({})
    end
    
    -- Get all players
    for _, player in pairs(QBCore.Functions.GetPlayers()) do
        local targetPlayer = QBCore.Functions.GetPlayer(player)
        if targetPlayer then
            table.insert(players, {
                id = player,
                name = targetPlayer.PlayerData.charinfo.firstname .. ' ' .. targetPlayer.PlayerData.charinfo.lastname,
                citizenid = targetPlayer.PlayerData.citizenid
            })
        end
    end
    
    cb(players)
end)

-- Add new wanted criminal
RegisterNetEvent('ng-wanted:server:addWanted', function(data)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then return end
    
    -- Check job permission
    if not Config.AllowedJobs[Player.PlayerData.job.name] then
        TriggerClientEvent('QBCore:Notify', src, 'Only police can use this function', 'error')
        return
    end
    
    -- Validate data
    if not data.criminalNames or #data.criminalNames == 0 then
        TriggerClientEvent('QBCore:Notify', src, 'Please select at least one criminal', 'error')
        return
    end
    
    if not data.crimes or #data.crimes == 0 then
        TriggerClientEvent('QBCore:Notify', src, 'Please select at least one crime', 'error')
        return
    end
    
    local fineAmount = tonumber(data.fine)
    if not fineAmount or fineAmount <= 0 then
        TriggerClientEvent('QBCore:Notify', src, 'Please set valid fine amount', 'error')
        return
    end
    
    -- Get wanted time and ensure it does not exceed maximum
    local wantedTimeMinutes = tonumber(data.wantedTime) or 0
    
    -- Validate wanted time
    if not wantedTimeMinutes or wantedTimeMinutes <= 0 then
        TriggerClientEvent('QBCore:Notify', src, 'Wanted time must be at least 1 minute', 'error')
        return
    end
    
    -- Auto-adjust if exceeds maximum
    if wantedTimeMinutes > Config.MaxWantedTime then
        wantedTimeMinutes = Config.MaxWantedTime
        TriggerClientEvent('QBCore:Notify', src, 'Wanted time exceeded maximum (' .. Config.MaxWantedTime .. ' min). Automatically adjusted to ' .. Config.MaxWantedTime .. ' minutes.', 'warning')
    end
    
    -- Calculate wanted until timestamp
    local currentTimestamp = os.time()
    local wantedSeconds = wantedTimeMinutes * 60
    local wantedUntil = currentTimestamp + wantedSeconds
    
    -- Convert to MySQL timestamp format
    local formattedTime = os.date('%Y-%m-%d %H:%M:%S', wantedUntil)
    
    -- List of added criminals
    local addedCriminals = {}
    
    -- Process all criminals
    for i, criminalName in ipairs(data.criminalNames) do
        -- Save to database
        local success, result = pcall(function()
            MySQL.Async.insert('INSERT INTO '..Config.DatabaseTable..' (criminal_name, crimes, fine, wanted_until, added_by) VALUES (?, ?, ?, ?, ?)', {
                criminalName,
                json.encode(data.crimes),
                fineAmount,
                formattedTime,
                Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname
            }, function(id)
                if id then
                    -- Add name to list if successful
                    table.insert(addedCriminals, criminalName)
                    
                    -- Send messages when all processing is complete
                    if i == #data.criminalNames then
                        -- Success message to registrar
                        TriggerClientEvent('QBCore:Notify', src, #addedCriminals .. ' criminals added to wanted list', 'success')
                        
                        -- Notification to all players
                        if #addedCriminals > 0 then
                            local notifyMsg = ''
                            if #addedCriminals == 1 then
                                notifyMsg = addedCriminals[1] .. ' has been wanted'
                            else
                                notifyMsg = #addedCriminals .. ' criminals have been wanted'
                            end
                            
                            -- Create detailed information
                            local crimesInfo = {}
                            for _, crimeIndex in ipairs(data.crimes) do
                                if Config.Crimes[crimeIndex + 1] then -- JavaScript is 0-indexed, Lua is 1-indexed
                                    table.insert(crimesInfo, Config.Crimes[crimeIndex + 1].label)
                                end
                            end
                            
                            local detailMsg = ''
                            if #crimesInfo > 0 then
                                detailMsg = 'Crimes: ' .. table.concat(crimesInfo, ', ') .. ' / Fine: $' .. data.fine .. ' / Wanted time: ' .. data.wantedTime .. ' min'
                            end
                            
                            -- Notify all players
                            TriggerClientEvent('ng-wanted:client:notifyWanted', -1, notifyMsg .. '\n' .. detailMsg)
                            
                            -- Wait and play sound again for emphasis
                            Citizen.Wait(5000) -- Wait 5 seconds
                            TriggerClientEvent('ng-wanted:client:notifyWanted', -1, 'WARNING: Wanted list updated')
                            
                            -- Notify all clients to refresh wanted list
                            TriggerClientEvent('ng-wanted:client:refreshWantedList', -1)
                        end
                    end
                else
                    TriggerClientEvent('QBCore:Notify', src, 'Failed to add wanted for ' .. criminalName, 'error')
                end
            end)
        end)
        
        if not success then
            print('Database error:', result)
            TriggerClientEvent('QBCore:Notify', src, 'System error occurred. Please contact administrator.', 'error')
        end
    end
end)

-- Remove wanted criminal
RegisterNetEvent('ng-wanted:server:removeWanted', function(wantedId)
    local src = source
    
    -- Simple deletion with minimal error handling
    if type(wantedId) ~= "number" then
        wantedId = tonumber(wantedId) or 0
    end
    
    if wantedId <= 0 then
        return
    end
    
    -- Execute deletion
    MySQL.Sync.execute('DELETE FROM '..Config.DatabaseTable..' WHERE id = ?', {wantedId})
    
    -- Notify all clients to refresh list
    TriggerClientEvent('ng-wanted:client:refreshWantedList', -1)
end)

-- Auto-delete expired wanted (on server start and periodically)
local function cleanExpiredWanted()
    MySQL.Async.execute('DELETE FROM '..Config.DatabaseTable..' WHERE wanted_until < NOW()', {}, function(rowsChanged)
        if rowsChanged and type(rowsChanged) == "number" and rowsChanged > 0 then
            print('Deleted ' .. rowsChanged .. ' expired wanted entries')
            -- Notify all clients to refresh wanted list
            TriggerClientEvent('ng-wanted:client:refreshWantedList', -1)
        end
    end)
end

-- Execute on server start
CreateThread(function()
    cleanExpiredWanted()
    
    -- Check expired wanted every 5 minutes
    while true do
        Wait(5 * 60 * 1000) -- 5 minutes
        cleanExpiredWanted()
    end
end)
