local QBCore = exports['qb-core']:GetCoreObject()

-- データベーステーブルの作成
CreateThread(function()
    -- ショップアイテムテーブル
    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS ng_shops (
            shop_id VARCHAR(50) NOT NULL,
            item_name VARCHAR(50) NOT NULL,
            label VARCHAR(50) NOT NULL,
            buy_price INT DEFAULT 0,
            sell_price INT DEFAULT 0,
            PRIMARY KEY (shop_id, item_name)
        )
    ]])

    -- ショップ位置テーブル
    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS ng_shop_locations (
            shop_id VARCHAR(50) PRIMARY KEY,
            label VARCHAR(50) NOT NULL,
            coords_x FLOAT NOT NULL,
            coords_y FLOAT NOT NULL,
            coords_z FLOAT NOT NULL,
            heading FLOAT NOT NULL,
            jobs JSON,
            blip_enabled BOOLEAN DEFAULT true,
            blip_sprite INT DEFAULT 59,
            blip_color INT DEFAULT 25,
            blip_scale FLOAT DEFAULT 0.7
        )
    ]])
end)

-- ショップ一覧の取得
lib.callback.register('ng-shop:server:getShopLocations', function(source)
    local shops = MySQL.query.await('SELECT * FROM ng_shop_locations')
    for i, shop in ipairs(shops) do
        shop.jobs = json.decode(shop.jobs)
    end
    return shops
end)

-- ショップの追加/編集
lib.callback.register('ng-shop:server:updateShopLocation', function(source, shopData)
    local src = source
    if not IsPlayerAceAllowed(src, 'command.admin') then return false end

    local jobs = json.encode(shopData.jobs or {})
    MySQL.update.await([[
        INSERT INTO ng_shop_locations 
        (shop_id, label, coords_x, coords_y, coords_z, heading, jobs, 
        blip_enabled, blip_sprite, blip_color, blip_scale)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
        label = VALUES(label),
        coords_x = VALUES(coords_x),
        coords_y = VALUES(coords_y),
        coords_z = VALUES(coords_z),
        heading = VALUES(heading),
        jobs = VALUES(jobs),
        blip_enabled = VALUES(blip_enabled),
        blip_sprite = VALUES(blip_sprite),
        blip_color = VALUES(blip_color),
        blip_scale = VALUES(blip_scale)
    ]], {
        shopData.shop_id, shopData.label,
        shopData.coords_x, shopData.coords_y, shopData.coords_z,
        shopData.heading, jobs,
        shopData.blip_enabled, shopData.blip_sprite,
        shopData.blip_color, shopData.blip_scale
    })

    TriggerClientEvent('ng-shop:client:refreshShops', -1)
    return true
end)

-- ショップの削除
lib.callback.register('ng-shop:server:deleteShopLocation', function(source, shopId)
    local src = source
    if not IsPlayerAceAllowed(src, 'command.admin') then return false end

    MySQL.query.await('DELETE FROM ng_shop_locations WHERE shop_id = ?', {shopId})
    MySQL.query.await('DELETE FROM ng_shops WHERE shop_id = ?', {shopId})

    TriggerClientEvent('ng-shop:client:refreshShops', -1)
    return true
end)

-- ショップアイテムの取得
lib.callback.register('ng-shop:server:getShopItems', function(source, shopId)
    local items = MySQL.query.await('SELECT * FROM ng_shops WHERE shop_id = ?', {shopId})
    return items
end)

-- ショップアイテムを取得する関数
local function GetShopItem(shopId, itemName)
    local result = MySQL.single.await('SELECT * FROM ng_shops WHERE shop_id = ? AND item_name = ? LIMIT 1', {
        shopId,
        itemName
    })
    return result
end

-- アイテム購入のコールバック
lib.callback.register('ng-shop:server:buyItem', function(source, shopId, itemName, quantity, paymentMethod)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return false end

    -- アイテム情報の取得
    local item = GetShopItem(shopId, itemName)
    if not item then 
        TriggerClientEvent('ox_lib:notify', src, {
            type = 'error',
            description = 'アイテムが見つかりません'
        })
        return false 
    end

    -- 合計金額の計算
    local totalPrice = item.buy_price * quantity

    -- 支払い方法に応じて残高をチェック
    local canPay = false
    if paymentMethod == 'cash' then
        canPay = Player.Functions.GetMoney('cash') >= totalPrice
    else -- bank
        canPay = Player.Functions.GetMoney('bank') >= totalPrice
    end

    if canPay then
        -- 支払い処理
        Player.Functions.RemoveMoney(paymentMethod, totalPrice)
        
        -- アイテムの付与
        local success = Player.Functions.AddItem(itemName, quantity)
        if success then
            -- 購入ログの記録
            TriggerEvent('qb-log:server:CreateLog', 'shops', 'Item Purchase', 'green', 
                string.format('%s purchased %dx %s for $%d using %s', 
                    GetPlayerName(src), quantity, itemName, totalPrice, paymentMethod))
            
            -- 成功通知
            TriggerClientEvent('ox_lib:notify', src, {
                type = 'success',
                description = string.format('%dx %s を購入しました', quantity, item.label)
            })
            TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[itemName], "add")
            return true
        else
            -- 支払いの巻き戻し
            Player.Functions.AddMoney(paymentMethod, totalPrice)
            TriggerClientEvent('ox_lib:notify', src, {
                type = 'error',
                description = 'インベントリに空きがありません'
            })
            return false
        end
    else
        TriggerClientEvent('ox_lib:notify', src, {
            type = 'error',
            description = '所持金が不足しています'
        })
        return false
    end
end)

-- アイテムの売却
lib.callback.register('ng-shop:server:sellItem', function(source, shopId, itemName, amount)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return false end

    -- ショップアイテムの情報を取得
    local item = MySQL.single.await('SELECT * FROM ng_shops WHERE shop_id = ? AND item_name = ?', {
        shopId, itemName
    })
    if not item or item.sell_price <= 0 then return false end

    -- インベントリのチェック
    local hasItem = exports.ox_inventory:GetItem(src, itemName, nil, true) >= amount
    if not hasItem then
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'エラー',
            description = 'アイテムを持っていません',
            type = 'error'
        })
        return false
    end

    -- 売却価格の計算
    local totalPrice = item.sell_price * amount

    -- 取引の実行
    exports.ox_inventory:RemoveItem(src, itemName, amount)
    Player.Functions.AddMoney('cash', totalPrice)

    TriggerClientEvent('ox_lib:notify', src, {
        title = '売却完了',
        description = string.format('%s × %d を %d$で売却しました', item.label, amount, totalPrice),
        type = 'success'
    })
    return true
end)

-- 管理者権限チェック
lib.callback.register('ng-shop:server:isAdmin', function(source)
    return IsPlayerAceAllowed(source, 'command.admin')
end)

-- 管理者用：アイテムの追加/編集
lib.callback.register('ng-shop:server:updateItem', function(source, shopId, itemData)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return false end

    -- 管理者権限のチェック
    if not IsPlayerAceAllowed(src, 'command.admin') then
        return false
    end

    -- アイテムの更新/追加
    MySQL.update.await([[
        INSERT INTO ng_shops (shop_id, item_name, label, buy_price, sell_price)
        VALUES (?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
        label = VALUES(label),
        buy_price = VALUES(buy_price),
        sell_price = VALUES(sell_price)
    ]], {
        shopId,
        itemData.item_name,
        itemData.label,
        itemData.buy_price,
        itemData.sell_price
    })

    return true
end)

-- 管理者用：アイテムの削除
lib.callback.register('ng-shop:server:deleteItem', function(source, shopId, itemName)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return false end

    -- 管理者権限のチェック
    if not IsPlayerAceAllowed(src, 'command.admin') then
        return false
    end

    -- アイテムの削除
    MySQL.query.await('DELETE FROM ng_shops WHERE shop_id = ? AND item_name = ?', {
        shopId, itemName
    })

    return true
end)

-- job情報を更新するコールバック
lib.callback.register('ng-shop:server:updateShopJobs', function(source, shopId, jobs)
    local src = source
    if not IsPlayerAceAllowed(src, 'command.admin') then return false end

    local jobsJson = json.encode(jobs)
    MySQL.update.await('UPDATE ng_shop_locations SET jobs = ? WHERE shop_id = ?', {
        jobsJson, shopId
    })

    TriggerClientEvent('ng-shop:client:refreshShops', -1)
    return true
end)