local QBCore = exports['qb-core']:GetCoreObject()

-- キャッシュされたランキングデータ
local cachedExperienceRankings = {}
local lastRefresh = 0

-- ランキングデータの取得（経験値）
local function GetExperienceRankings()
    if (os.time() - lastRefresh) < Config.RefreshTime and #cachedExperienceRankings > 0 then
        return cachedExperienceRankings
    end
    
    local rankings = {}
    
    -- 照合順序の問題を避けるために2つのクエリに分割
    local result = MySQL.query.await([[
        SELECT citizenid, experience
        FROM m_fishing
        ORDER BY experience DESC
        LIMIT ?
    ]], {Config.RankingLimit})
    
    if result then
        for i, data in ipairs(result) do
            -- プレイヤー情報を個別に取得
            local playerInfo = {}
            local playerResult = MySQL.query.await('SELECT charinfo FROM players WHERE citizenid = ?', {data.citizenid})
            
            local name = nil
            if playerResult and playerResult[1] and playerResult[1].charinfo then
                local charInfo = json.decode(playerResult[1].charinfo) or {}
                name = charInfo.firstname and (charInfo.firstname .. ' ' .. charInfo.lastname) or nil
            end
            
            table.insert(rankings, {
                citizenid = data.citizenid,
                experience = data.experience,
                name = name
            })
        end
        
        cachedExperienceRankings = rankings
        lastRefresh = os.time()
    end
    
    return rankings
end

-- プレイヤーの順位を取得
local function GetPlayerRanking(citizenId)
    local result = MySQL.query.await([[
        SELECT 
            citizenid,
            experience,
            (SELECT COUNT(*) + 1 FROM m_fishing WHERE experience > m.experience) AS rank
        FROM 
            m_fishing AS m
        WHERE 
            citizenid = ?
    ]], {citizenId})
    
    if result and result[1] then
        return {
            rank = result[1].rank,
            experience = result[1].experience
        }
    end
    
    return { rank = '-', experience = 0 }
end

-- ランキングを開く
RegisterNetEvent('ng-fishing-ranking:server:openRanking', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then return end
    
    -- 強制的にキャッシュをクリアして最新データを取得
    cachedExperienceRankings = {}
    lastRefresh = 0
    
    local citizenId = Player.PlayerData.citizenid
    local experienceRankings = GetExperienceRankings()
    local playerRanking = GetPlayerRanking(citizenId)
    
    TriggerClientEvent('ng-fishing-ranking:client:openRanking', src, {
        experienceRankings = experienceRankings,
        playerRank = playerRanking.rank,
        playerExp = playerRanking.experience
    })
end)

-- ランキング更新のイベント（タブ切り替えは削除）
RegisterNetEvent('ng-fishing-ranking:server:requestRankings', function()
    local src = source
    TriggerClientEvent('ng-fishing-ranking:client:updateRankings', src, 'experience', GetExperienceRankings())
end)

-- デバッグコマンド
if Config.Debug then
    RegisterCommand('testrankingdata', function(source, args)
        local src = source
        
        -- テストデータの挿入
        MySQL.insert.await([[
            INSERT INTO m_fishing (citizenid, experience)
            VALUES (?, ?)
            ON DUPLICATE KEY UPDATE experience = ?
        ]], {
            'TEST'..math.random(1000, 9999),
            math.random(100, 1000),
            math.random(100, 1000)
        })
        
        QBCore.Functions.Notify(src, 'テストデータを追加しました', 'success')
    end, true)
end

-- サーバー起動時にテーブルが存在するか確認
MySQL.ready(function()
    -- m_fishingテーブルが存在するか確認し、なければ作成
    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS m_fishing (
            citizenid VARCHAR(50) PRIMARY KEY,
            experience INT DEFAULT 0
        )
    ]])
    
    print('[ng-fishing-ranking] データベーステーブルの確認が完了しました')
    
    -- 初回ランキングデータをキャッシュ
    GetExperienceRankings()
end)