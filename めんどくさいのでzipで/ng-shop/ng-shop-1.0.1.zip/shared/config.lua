Config = {}

-- アイテムのデフォルト設定
Config.DefaultItems = {}