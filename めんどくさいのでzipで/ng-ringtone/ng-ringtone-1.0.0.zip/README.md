# NG-Ringtone (LB-Phone用リングトーン変更アプリ)

## スクリプトの説明
「NG-Ringtone」は、LB-Phone用のリングトーン変更アプリです。プレイヤーは電話の着信音をカスタマイズでき、自分だけのオリジナルな着信音を設定することができます。

### 主な機能
- カスタム着信音の追加、編集、削除
- デフォルト着信音の設定
- 着信音のプレビュー機能
- 着信音のミュート設定
- 自分に聞こえる音量設定
- 複数の着信音を登録して簡単に切り替え可能

## 依存関係
このスクリプトは以下のリソースに依存しています：
- [qb-core](https://github.com/qbcore-framework/qb-core) もしくはqbxでも可
- [lb-phone](https://github.com/lbphone/lb-phone)
- [xsound](https://github.com/Xogy/xsound)
- [oxmysql](https://github.com/overextended/oxmysql)

## インストール手順

### portal.cfx.reからダウンロード
1. [portal.cfx.re](https://portal.cfx.re)からスクリプトをダウンロードします。
2. ダウンロードしたZIPファイルを解凍します。
3. `ng-ringtone`フォルダをサーバーの`resources`フォルダに配置します。

### server.cfgの設定
4. サーバーの`server.cfg`または`resources.cfg`にリソースを追加します。
   ```
   ensure qb-core
   ensure oxmysql
   ensure xsound
   ensure lb-phone
   ensure ng-ringtone  # 必ずlb-phoneの後に配置してください
   ```

   **重要**: `ng-ringtone`は必ず`lb-phone`の後に起動するように設定してください。順序が正しくないと正常に動作しません。

5. サーバーを再起動するか、以下のコマンドを実行します：
   ```
   refresh
   ensure ng-ringtone
   ```

6. lb-phone/config/config.jsonに以下の設定を追加します。
"sounds": の中に "custom_ringtone": "custom_ringtone" を追加
例

    "sounds": {
        "ringtone": {
            "default": "default.mp3",
            "harp": "harp.mp3",
            "apex": "apex.mp3",
            "radar": "radar.mp3",
            "sencha": "sencha.mp3",
            "silk": "silk.mp3",
            "summit": "summit.mp3",
            "custom_ringtone": "custom_ringtone"
        },
        "texttone": {
            "default": "default.mp3"
        },
        "appNotifications": {}
    },

## 使用方法
1. LB-Phoneを開きます。
2. LB-Phoneの設定から以下の設定に変更してください。
サウンド -> 着信音 -> custom_ringtone
※上記のインストール手順を正しく出来ていない場合は存在しない可能性があります。
3. 「リングトーン」アプリを選択します。
4. アプリ内で以下の操作が可能です

### 着信音の追加
1. アプリ内の追加ボタンをクリックします。
2. 着信音の名前を入力します（例：「お気に入り1」）。
3. 着信音のURLを入力します（MP3、WAV、OGGなどの直接リンク）。
4. 「保存」をクリックします。

### デフォルト着信音の設定
1. 保存済みリストから設定したい音を選択します。
2. 「デフォルトに設定」をクリックします。(★マーク)
3. 設定された着信音は次回の着信から使用されます。

### 着信音の編集・削除
1. 着信音リストから編集したい音を選択します。
2. 「編集」または「削除」をクリックして変更を行います。

### 音量設定
1. 設定メニューから音量を調整できます。
2. 「自分の音量」：自分が聞こえる着信音の音量

### ミュート設定
1. アプリ内の「ミュート」トグルをクリックすると、着信音をミュートできます。
2. ミュート状態でも着信自体は通知されます。

## 注意事項
- 着信音のURLは直接アクセス可能な音声ファイル（MP3, WAV, OGGなど）である必要があります。
- YouTubeのURLなどは直接使用できます。
- 使用する音声ファイルの権利を確認してください。
- 大きなファイルサイズの音声は読み込みに時間がかかる場合があります。

## トラブルシューティング
1. 着信音が再生されない場合：
   - xsoundリソースが正しく動作しているか確認してください。
   - 音声ファイルのURLが有効であることを確認してください。
   - ブラウザで直接URLにアクセスして、音声ファイルが再生できるか確認してください。

2. アプリがLB-Phoneに表示されない場合：
   - LB-Phoneリソースが起動しているか確認してください。
   - ng-ringtoneがlb-phoneの後に起動されているか確認してください。
   - サーバーログでエラーメッセージを確認してください。