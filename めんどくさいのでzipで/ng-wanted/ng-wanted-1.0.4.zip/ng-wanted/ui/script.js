// グローバル変数
let crimesList = [];
let wantedList = [];
let maxWantedTime = 60; // デフォルト値
let playersList = [];
let isCivilianMode = false; // 一般市民モードのフラグ

// MP3サウンド再生用のAudioオブジェクト
let soundAudio = null;

// サウンド再生関数
function playSound(soundFile, volume) {
    try {
        // 既存の音声を停止
        if (soundAudio) {
            soundAudio.pause();
            soundAudio.currentTime = 0;
        }
        
        // 新しい音声を再生
        soundAudio = new Audio(`sounds/${soundFile}`);
        soundAudio.volume = volume || 0.5;
        soundAudio.play().catch(error => {
            console.error('音声再生エラー:', error);
        });
    } catch (error) {
        console.error('音声ロードエラー:', error);
    }
}

// 登録ボタンの状態を更新する関数（グローバルスコープに配置）
function updateSubmitButtonState() {
    const manualInput = document.getElementById('manual-input');
    const criminalName = document.getElementById('criminal-name');
    const criminalsSelect = document.getElementById('criminals-select');
    const submitButton = document.getElementById('submit-wanted');
    
    if (!submitButton) return; // UIが読み込まれていない場合は何もしない
    
    // 犯罪者が選択されているかチェック
    let hasCriminal = false;
    
    // 手動入力モードの場合
    if (manualInput && manualInput.checked) {
        hasCriminal = criminalName && criminalName.value.trim() !== '';
    } else {
        // ドロップダウン選択モードの場合
        hasCriminal = criminalsSelect && criminalsSelect.selectedOptions.length > 0;
    }
    
    // 罪名が選択されているかチェック
    const hasCrimes = document.querySelectorAll('#crimes-container input[type="checkbox"]:checked').length > 0;
    
    // 罰金が入力されているかチェック
    const hasFine = document.getElementById('fine') && document.getElementById('fine').value.trim() !== '';
    
    // 指名手配時間が入力されているかチェック
    const hasWantedTime = document.getElementById('wanted-time') && document.getElementById('wanted-time').value.trim() !== '';
    
    // すべての必須フィールドが入力されている場合のみボタンを有効化
    if (hasCriminal && hasCrimes && hasFine && hasWantedTime) {
        submitButton.disabled = false;
        submitButton.classList.remove('disabled');
    } else {
        submitButton.disabled = true;
        submitButton.classList.add('disabled');
    }
}

// UIの初期化
window.addEventListener('message', function(event) {
    const data = event.data;

    if (data.type === "ui") {
        // UI表示/非表示の切り替え
        document.body.style.display = data.status ? "block" : "none";
        
        // 市民モードの設定
        isCivilianMode = data.civilianMode || false;
        
        if (isCivilianMode) {
            document.body.classList.add('civilian-mode');
            document.getElementById('police-header').classList.add('civilian-header');
            
            // タイトルの設定（市民用）
            if (data.config && data.config.civilian_title) {
                document.getElementById('title').textContent = data.config.civilian_title;
            }
        } else {
            document.body.classList.remove('civilian-mode');
            document.getElementById('police-header').classList.remove('civilian-header');
            
            // タイトルの設定（警察用）
            if (data.config) {
                document.getElementById('title').textContent = data.config.title || "ロスサントス市警 - 指名手配システム";
            }
        }
    } 
    else if (data.type === "init") {
        // 市民モードの設定
        isCivilianMode = data.civilianMode || false;
        
        if (isCivilianMode) {
            document.body.classList.add('civilian-mode');
            document.getElementById('police-header').classList.add('civilian-header');
        } else {
            document.body.classList.remove('civilian-mode');
            document.getElementById('police-header').classList.remove('civilian-header');
        }
        
        // 初期データのロード
        crimesList = data.crimesList || [];
        wantedList = data.wantedList || [];
        maxWantedTime = data.maxWantedTime || 60;
        playersList = data.playersList || [];
        
        // 最大時間の表示と入力制限を設定
        if (!isCivilianMode) {
            document.getElementById('max-time-value').textContent = maxWantedTime;
            document.getElementById('wanted-time').setAttribute('max', maxWantedTime);
            
            // 罪名チェックボックスの生成
            generateCrimesCheckboxes();
            
            // プレイヤーリストのドロップダウン生成
            generatePlayersDropdown();
        }
        
        // 指名手配リストの表示
        renderWantedList();
    }
    else if (data.type === "refreshList") {
        // 指名手配リストの更新
        wantedList = data.wantedList || [];
        renderWantedList();
    }
    else if (data.type === "playSound") {
        // MP3サウンド再生
        playSound(data.sound, data.volume);
    }
});

// プレイヤーリストのドロップダウン生成
function generatePlayersDropdown() {
    const select = document.getElementById('criminals-select');
    select.innerHTML = ''; // 既存のオプションをクリア
    
    playersList.forEach(player => {
        const option = document.createElement('option');
        option.value = player.id;
        option.textContent = `${player.name} [${player.citizenid}]`;
        option.dataset.name = player.name;
        option.dataset.citizenid = player.citizenid;
        select.appendChild(option);
    });
}

// 手動入力の切り替え
document.addEventListener('DOMContentLoaded', function() {
    const manualInput = document.getElementById('manual-input');
    const criminalName = document.getElementById('criminal-name');
    const criminalsSelect = document.getElementById('criminals-select');
    const wantedTimeInput = document.getElementById('wanted-time');
    const submitButton = document.getElementById('submit-wanted');
    
    // ボタン状態の初期化（最初は無効）
    updateSubmitButtonState();
    
    // 指名手配時間入力の制限を追加
    wantedTimeInput.addEventListener('input', function() {
        // 入力値が最大値を超えた場合に自動的に制限する
        const inputVal = parseInt(this.value);
        if (!isNaN(inputVal) && inputVal > maxWantedTime) {
            this.value = maxWantedTime;
        }
        
        // ボタン状態の更新
        updateSubmitButtonState();
    });
    
    // フォーム送信前に再度確認
    wantedTimeInput.addEventListener('blur', function() {
        const inputVal = parseInt(this.value);
        if (!isNaN(inputVal) && inputVal > maxWantedTime) {
            this.value = maxWantedTime;
            alert(`指名手配時間は最大${maxWantedTime}分までです。自動的に${maxWantedTime}分に調整しました。`);
        }
        
        // ボタン状態の更新
        updateSubmitButtonState();
    });
    
    manualInput.addEventListener('change', function() {
        if (this.checked) {
            criminalName.disabled = false;
            criminalsSelect.disabled = true;
        } else {
            criminalName.disabled = true;
            criminalsSelect.disabled = false;
        }
        
        // ボタン状態の更新
        updateSubmitButtonState();
    });
    
    // 手動入力欄の入力監視
    criminalName.addEventListener('input', function() {
        updateSubmitButtonState();
    });
    
    // 複数選択された場合の名前生成
    criminalsSelect.addEventListener('change', function() {
        if (!manualInput.checked) {
            // 選択された全オプションを取得
            const selectedOptions = Array.from(this.selectedOptions);
            
            if (selectedOptions.length > 0) {
                // 複数選択の場合は名前をカンマで区切る
                const names = selectedOptions.map(option => 
                    `${option.dataset.name} [${option.dataset.citizenid}]`
                );
                
                // 名前入力欄に設定
                criminalName.value = names.join(', ');
            } else {
                criminalName.value = '';
            }
        }
        
        // ボタン状態の更新
        updateSubmitButtonState();
    });
    
    // 罪名チェックボックス変更時の処理
    document.getElementById('crimes-container').addEventListener('change', function() {
        updateSubmitButtonState();
    });
    
    // 罰金入力時の処理
    document.getElementById('fine').addEventListener('input', function() {
        updateSubmitButtonState();
    });
});


// 閉じるボタンの設定
document.getElementById('close-button').addEventListener('click', function() {
    closeUI();
});

// Escキーで閉じる
document.addEventListener('keyup', function(event) {
    if (event.key === "Escape") {
        closeUI();
    }
});

// UIを閉じる関数
function closeUI() {
    fetch(`https://${GetParentResourceName()}/close`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({})
    }).then(response => response.json());
    
    document.body.style.display = "none";
}

// 罪名チェックボックスの生成
function generateCrimesCheckboxes() {
    const container = document.getElementById('crimes-container');
    container.innerHTML = '';
    
    crimesList.forEach((crime, index) => {
        const checkboxDiv = document.createElement('div');
        checkboxDiv.className = 'crime-checkbox';
        
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.id = `crime-${index}`;
        checkbox.dataset.crimeIndex = index;
        checkbox.dataset.fine = crime.fine; // 罰金額をデータ属性に保存
        
        // 罪名チェックボックスの変更イベント（罰金自動計算用）
        checkbox.addEventListener('change', function() {
            calculateFine();
        });
        
        const label = document.createElement('label');
        label.htmlFor = `crime-${index}`;
        label.textContent = `${crime.label} ($${crime.fine})`;
        
        checkboxDiv.appendChild(checkbox);
        checkboxDiv.appendChild(label);
        container.appendChild(checkboxDiv);
    });
}

// 罰金を自動計算する関数
function calculateFine() {
    const fineInput = document.getElementById('fine');
    
    // 選択された罪名のチェックボックスを取得
    const selectedCrimes = document.querySelectorAll('#crimes-container input[type="checkbox"]:checked');
    
    if (selectedCrimes.length === 0) {
        // 何も選択されていない場合はクリア
        fineInput.value = '';
        return;
    }
    
    let totalFine = 0;
    selectedCrimes.forEach(checkbox => {
        // data-fine属性から罰金額を取得
        const crimeFine = parseInt(checkbox.dataset.fine);
        if (!isNaN(crimeFine)) {
            totalFine += crimeFine;
        }
    });
    
    // 罰金フィールドに設定
    fineInput.value = totalFine;
}

// 指名手配リストの表示
function renderWantedList() {
    const container = document.getElementById('list-container');
    container.innerHTML = '';
    
    if (wantedList.length === 0) {
        const emptyMessage = document.createElement('div');
        emptyMessage.className = 'empty-message';
        emptyMessage.textContent = '現在指名手配されている犯罪者はいません';
        container.appendChild(emptyMessage);
        return;
    }
    
    wantedList.forEach(wanted => {
        // 残り時間の計算
        const wantedUntil = new Date(wanted.wanted_until);
        const now = new Date();
        const timeRemainingSecs = Math.max(0, Math.floor((wantedUntil - now) / 1000)); // 秒単位
        
        // カードの作成
        const card = document.createElement('div');
        card.className = 'wanted-card';
        
        // ヘッダー
        const name = document.createElement('h3');
        name.textContent = wanted.criminal_name;
        card.appendChild(name);
        
        // 削除ボタン（一般市民モードでは表示しない）
        if (!isCivilianMode) {
            const removeBtn = document.createElement('div');
            removeBtn.className = 'remove-btn';
            removeBtn.innerHTML = '<i class="fas fa-times"></i>';
            removeBtn.dataset.id = wanted.id;
            removeBtn.addEventListener('click', function() {
                removeWanted(wanted.id);
            });
            card.appendChild(removeBtn);
        }
        
        // 罪名
        const crimesRow = document.createElement('div');
        crimesRow.className = 'info-row';
        
        const crimesLabel = document.createElement('div');
        crimesLabel.className = 'info-label';
        crimesLabel.textContent = '罪名:';
        crimesRow.appendChild(crimesLabel);
        
        const crimesListElement = document.createElement('div');
        crimesListElement.className = 'crimes-list';
        
        wanted.crimes.forEach(crimeIndex => {
            if (crimesList[crimeIndex]) {
                const crimeTag = document.createElement('div');
                crimeTag.className = 'crime-tag';
                crimeTag.textContent = crimesList[crimeIndex].label;
                crimesListElement.appendChild(crimeTag);
            }
        });
        
        crimesRow.appendChild(crimesListElement);
        card.appendChild(crimesRow);
        
        // 罰金
        const fineRow = document.createElement('div');
        fineRow.className = 'info-row';
        
        const fineLabel = document.createElement('div');
        fineLabel.className = 'info-label';
        fineLabel.textContent = '罰金:';
        fineRow.appendChild(fineLabel);
        
        const fineValue = document.createElement('div');
        fineValue.textContent = `$${wanted.fine.toLocaleString()}`;
        fineRow.appendChild(fineValue);
        
        card.appendChild(fineRow);
        
        // 残り時間
        const timeRow = document.createElement('div');
        timeRow.className = 'info-row';
        
        const timeLabel = document.createElement('div');
        timeLabel.className = 'info-label';
        timeLabel.textContent = '残り時間:';
        timeRow.appendChild(timeLabel);
        
        const timeValue = document.createElement('div');
        timeValue.className = 'time-remaining';
        
        // 分と秒に変換
        const minutes = Math.floor(timeRemainingSecs / 60);
        const seconds = timeRemainingSecs % 60;
        
        // 分(秒)の形式で表示
        timeValue.textContent = `${minutes}分${seconds}秒`;
        
        timeRow.appendChild(timeValue);
        card.appendChild(timeRow);
        
        // フッター
        const footer = document.createElement('div');
        footer.className = 'wanted-footer';
        footer.textContent = `登録者: ${wanted.added_by} - ${new Date(wanted.added_at).toLocaleString('ja-JP')}`;
        card.appendChild(footer);
        
        container.appendChild(card);
    });
}

// 新規指名手配の登録
document.getElementById('submit-wanted').addEventListener('click', function() {
    // フォームからデータ取得
    let criminalNames = [];
    let playerIds = [];
    
    // 手動入力かドロップダウン選択かを確認
    if (document.getElementById('manual-input').checked) {
        // 手動入力の場合は単一の文字列として扱う
        const inputName = document.getElementById('criminal-name').value;
        if (inputName.trim() !== '') {
            criminalNames.push(inputName);
        }
    } else {
        // 選択ドロップダウンから選択された犯罪者を取得
        const criminalsSelect = document.getElementById('criminals-select');
        const selectedOptions = Array.from(criminalsSelect.selectedOptions);
        
        if (selectedOptions.length > 0) {
            // 各選択された犯罪者の情報を配列に追加
            selectedOptions.forEach(option => {
                criminalNames.push(`${option.dataset.name} [${option.dataset.citizenid}]`);
                playerIds.push(option.value);
            });
        }
    }
    
    const fine = parseInt(document.getElementById('fine').value);
    const wantedTime = parseInt(document.getElementById('wanted-time').value);
    
    // 罪名のチェック項目を取得
    const selectedCrimes = [];
    document.querySelectorAll('#crimes-container input[type="checkbox"]:checked').forEach(checkbox => {
        selectedCrimes.push(parseInt(checkbox.dataset.crimeIndex));
    });
    
    // バリデーション
    if (criminalNames.length === 0) {
        alert('犯罪者を選択するか、名前を入力してください');
        return;
    }
    
    if (selectedCrimes.length === 0) {
        alert('少なくとも1つの罪名を選択してください');
        return;
    }
    
    if (isNaN(fine) || fine <= 0) {
        alert('有効な罰金額を入力してください');
        return;
    }
    
    if (isNaN(wantedTime) || wantedTime <= 0) {
        alert(`指名手配時間は1分以上で設定してください`);
        return;
    }
    
    if (wantedTime > maxWantedTime) {
        alert(`指名手配時間が最大値(${maxWantedTime}分)を超えています。\n${maxWantedTime}分以下の値を設定してください。`);
        document.getElementById('wanted-time').value = maxWantedTime; // 自動的に最大値を設定
        return;
    }
    
    // 最終バリデーション: 最大時間を超えていないか再確認
    if (wantedTime > maxWantedTime) {
        wantedTime = maxWantedTime; // 最大値に自動調整
        document.getElementById('wanted-time').value = maxWantedTime;
        alert(`入力された時間が最大値を超えているため、${maxWantedTime}分に自動調整しました。`);
        // ここで return しないで処理を続行する
    }
    
    try {
        // データ送信 - すべての犯罪者に対して一括で送信
        fetch(`https://${GetParentResourceName()}/addWanted`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json; charset=UTF-8',
            },
            body: JSON.stringify({
                criminalNames: criminalNames,
                playerIds: playerIds,  // プレイヤーIDも送信
                crimes: selectedCrimes,
                fine,
                wantedTime
            })
        }).catch(error => {
            console.error('送信エラー:', error);
            alert('データ送信中にエラーが発生しました。もう一度試してください。');
        });
        
        // フォームリセット
        document.getElementById('criminal-name').value = '';
        document.getElementById('criminals-select').selectedIndex = -1; // 複数選択をクリア
        document.getElementById('fine').value = '';
        document.getElementById('wanted-time').value = '';
        document.querySelectorAll('#crimes-container input[type="checkbox"]:checked').forEach(checkbox => {
            checkbox.checked = false;
        });
        
        // ボタン状態の更新 - フォームリセット後にボタンを無効化
        updateSubmitButtonState();
    } catch (error) {
        console.error('予期せぬエラー:', error);
        alert('予期せぬエラーが発生しました。もう一度お試しください。');
    }
});

// 指名手配の削除
// 削除ボタンクリック時はIDを送信するだけのシンプルな実装に変更
function removeWanted(id) {
    fetch(`https://${GetParentResourceName()}/removeWanted`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({
            id: id
        })
    });
}

// 1秒ごとに残り時間を更新
setInterval(() => {
    if (document.body.style.display === "block") {
        renderWantedList();
    }
}, 1000);