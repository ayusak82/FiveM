# NGSubscribe - QBCore サブスクリプション管理システム

## 概要
NGSubscribeは、FiveMサーバー向けのサブスクリプション管理システムです。Discord連携を利用して、プレイヤーに特典を自動付与することができます。

## 特徴
- Discord役職に基づく自動サブスクリプション付与
- 複数のサブスクリプションプラン管理
- 報酬システム（現金・アイテム）
- 車両付与システム
- 管理者用コントロールパネル
- Webhook通知システム

## 必要要件
- QBCore Framework
- ox_lib
- oxmysql
- ox_inventory または qs-inventory

## インストール手順

1. データベースのインポート
- サーバーの起動時に自動的にテーブルが作成されます

2. server.cfgの設定
```cfg
ensure ox_lib
ensure oxmysql
ensure ox_inventory # または qs-inventory
ensure ng-subscribe
```

## 設定方法

### Discord Bot設定

1. Discord Developerポータルで新しいBotを作成
2. 以下の権限を付与:
   - Server Members Intent
   - Message Content Intent
   - 必要なBot権限

3. `config.lua`にBot情報を設定:
```lua
Config.Discord = {
    BotToken = 'YOUR_BOT_TOKEN',
    GuildId = 'YOUR_GUILD_ID',
    Roles = {
        ['ROLE_ID'] = 'gold',  -- 役職IDとプラン名
    },
    AdminRoles = {
        'ADMIN_ROLE_ID'
    }
}
```

### Webhook設定
```lua
Config.Discord.Webhooks = {
    rewards = 'WEBHOOK_URL',
    vehicles = 'WEBHOOK_URL',
    subscriptions = 'WEBHOOK_URL'
}
```

### プラン設定
```lua
Config.Plans = {
    ['bronze'] = {
        label = 'ブロンズプラン',
        level = 1,
        rewards = {
            cash = 1000000,
            items = {
                ['phone'] = 1,
                ['radio'] = 1
            },
            vehicle_categories = {'sports', 'muscle'}
        }
    }
}
```

## コマンド一覧

### プレイヤーコマンド
- `/subs` - サブスクリプションメニューを開く

### 管理者コマンド
- `/subsadmin` - 管理者メニューを開く
- `/forcesubs` - 全プレイヤーのサブスクリプションを強制更新
- `/forceplayersubs [id]` - 特定プレイヤーのサブスクリプションを強制更新

## 機能説明

### サブスクリプション自動付与
- プレイヤーがサーバーに参加時に自動チェック
- 毎月1日に自動更新
- Discord役職に基づく自動付与

### 報酬システム
- 現金報酬
- アイテム報酬
- 車両選択システム

### 管理者機能
- プレイヤー情報確認
- プラン変更
- 強制更新
- サブスクリプション失効

## トラブルシューティング

1. サブスクリプションが自動付与されない
- Discord Botのトークンと権限を確認
- プレイヤーのDiscord連携を確認
- サーバーコンソールのエラーログを確認

2. アイテムが受け取れない
- インベントリシステムの設定を確認
- アイテム名がQBCore.Shared.Itemsに存在するか確認
- インベントリの容量を確認

3. 車両が受け取れない
- 車両名がQBCore.Shared.Vehiclesに存在するか確認
- カテゴリー設定を確認
- ブラックリスト設定を確認

## サポート
問題が発生した場合は、Discordにてayusakまでお願いします。
