Config = {}

-- インベントリシステムの選択
Config.InventoryType = 'ox' -- 'ox' または 'qs'

Config.Inventory = {
    ['ox'] = {
        addItem = function(source, item, count)
            return exports.ox_inventory:AddItem(source, item, count)
        end,
        removeItem = function(source, item, count)
            return exports.ox_inventory:RemoveItem(source, item, count)
        end,
        hasItem = function(source, item, count)
            return exports.ox_inventory:GetItem(source, item, nil, true) >= (count or 1)
        end,
        canCarry = function(source, item, count)
            return exports.ox_inventory:CanCarryItem(source, item, count)
        end
    },
    ['qs'] = {
        addItem = function(source, item, count)
            return exports['qs-inventory']:AddItem(source, item, count)
        end,
        removeItem = function(source, item, count)
            return exports['qs-inventory']:RemoveItem(source, item, count)
        end,
        hasItem = function(source, item, count)
            return exports['qs-inventory']:GetItemTotalAmount(source, item) >= (count or 1)
        end,
        canCarry = function(source, item, count)
            -- QS Inventoryの場合は適切な関数に置き換えてください
            return true
        end
    }
}

Config.Discord = {
    Webhooks = {
        rewards = 'https://discord.com/api/webhooks/example',
        vehicles = 'https://discord.com/api/webhooks/example',
        subscriptions = 'https://discord.com/api/webhooks/example'
    },
    Roles = {
        ['00000000000000'] = 'bronze',
        ['00000000000000'] = 'silver',
        ['00000000000000'] = 'gold'
    },
    AdminRoles = {
        '00000000000000'
    },
    BotToken = 'TOKEN',
    GuildId = '00000000000000',
    CheckInterval = 60,
    LinkTimeout = 300
}

Config.Vehicles = {
    BlacklistedVehicles = {
        'oppressor',
        'oppressor2',
        'lazer',
        'hydra'
    },
    PlanBlacklist = {
        ['bronze'] = {
            'adder',
            't20'
        },
        ['silver'] = {
            't20'
        }
    }
}

Config.VehicleCategories = {
    'sports',
    'super',
    'muscle',
    'sedans',
    'suvs',
    'coupes',
    'compacts'
}

Config.Plans = {
    ['bronze'] = {
        label = 'ブロンズプラン',
        level = 1,
        rewards = {
            cash = 1000000,
            items = {
                ['phone'] = 1,
                ['radio'] = 1,
                ['lockpick'] = 5
            },
            vehicle_categories = {'sports', 'muscle', 'sedans'}
        }
    },
    ['silver'] = {
        label = 'シルバープラン',
        level = 2,
        rewards = {
            cash = 2000000,
            items = {
                ['phone'] = 1,
                ['radio'] = 1,
                ['lockpick'] = 10,
                ['armor'] = 5
            },
            vehicle_categories = {'sports', 'muscle', 'sedans', 'suvs', 'coupes'}
        }
    },
    ['gold'] = {
        label = 'ゴールドプラン',
        level = 3,
        rewards = {
            cash = 3000000,
            items = {
                ['phone'] = 1,
                ['radio'] = 1,
                ['lockpick'] = 15,
                ['armor'] = 10,
                ['repairkit'] = 5
            },
            vehicle_categories = Config.VehicleCategories
        }
    }
}

Config.UI = {
    AdminCommand = 'subsadmin',
    PlayerCommand = 'subs'
}

Config.WebhookMessages = {
    rewards = {
        title = '🎁 サブスクリプション報酬受け取りログ',
        color = 5763719,
        format = [=[
            プレイヤー: %s
            CitizenID: %s
            プラン: %s
            受け取り内容:
            - 現金: $%s
            - アイテム: %s
        ]=]
    },
    vehicles = {
        title = '🚗 サブスクリプション車両受け取りログ',
        color = 5763719,
        format = [=[
            プレイヤー: %s
            CitizenID: %s
            プラン: %s
            受け取った車両: %s
            カテゴリー: %s
        ]=]
    },
    subscriptions = {
        title = '✨ サブスクリプション付与ログ',
        color = 5763719,
        format = [=[
            プレイヤー: %s
            CitizenID: %s
            付与されたプラン: %s
            付与方法: %s
        ]=]
    }
}

Config.Messages = {
    error = {
        no_subscription = '有効なサブスクリプションがありません',
        already_claimed = 'すでに受け取り済みです',
        vehicle_blacklisted = 'この車両は現在のプランでは選択できません',
        insufficient_permission = '権限がありません'
    },
    success = {
        rewards_claimed = '報酬を受け取りました',
        vehicle_claimed = '車両を受け取りました',
        subscription_added = 'サブスクリプションを付与しました'
    }
}