Config = {}

-- Discord Webhook URL("https://discord.webhook") または false
Config.Webhook = false

-- UI表示キー設定
Config.OpenKey = 'F7'

-- ace権限設定
Config.AdminGroup = 'group.admin'

-- バンキングシステム設定
-- 'renewed' : Renewed-Banking
-- 'qb' : QB-Banking
-- 'okok' : okokBanking
-- 'qb-management' : qb-management
Config.BankingSystem = 'renewed'

-- QBCoreの種類設定
-- 'qb' または 'qbx'
Config.QBType = 'qbx'

-- データベーステーブル設定
Config.Database = {
    renewed = {
        accounts = 'bank_accounts_new',
        transactions = 'player_transactions'
    },
    ['qb-management'] = {
        accounts = 'management_funds',
        type = 'boss'
    },
    qb = {
        accounts = 'bank_accounts',
        statements = 'bank_statements'
    },
    okok = {
        transactions = 'okokbanking_transactions',
        societies = 'okokbanking_societies'
    }
}

-- 強制執行が可能な職業リスト
Config.ForcePaymentJobs = {
    ['police'] = true,
    ['ambulance'] = true,
    ['mechanic'] = true,
    ['speedfast'] = true,
}

-- 強制執行の設定
Config.ForcePayment = {
    allowNegativeBalance = false, -- trueの場合、残高がマイナスになることを許可
    checkAccounts = {  -- 残高チェック対象の口座タイプ
        bank = true,   -- 銀行口座
        cash = true    -- 現金所持
    }
}

-- プリセット請求を使用できる職業リスト（その他の職業はその他の金額のみ使用可能）
Config.JobList = {
    ['police'] = true,
    ['ambulance'] = true,
    ['mechanic'] = true,
    ['speedfast'] = true,
    ['soiree'] = true,
    ['tabakonobu'] = true,
    ['noramengantetu'] = true,
    ['lapiccolafelicita'] = true,
    ['harem'] = true,
}

-- 職業ごとの収入分配率設定（%） - 設定された%が職業口座に入金
Config.JobPaymentRatio = {
    ['police'] = 50,     -- 50%が職業口座、50%が個人の手持ち
    ['ambulance'] = 50,  -- 50%が職業口座、50%が個人の手持ち
    ['mechanic'] = 70,   -- 70%が職業口座、30%が個人の手持ち
    ['speedfast'] = 70,
    ['soiree'] = 50,
    ['tabakonobu'] = 50,
    ['noramengantetu'] = 50,
    ['lapiccolafelicita'] = 30,
    ['harem'] = 30,
}

-- 職業ごとの請求内容プリセット
Config.JobInvoicePresets = {
    ['police'] = {
        {label = '武器ライセンス発行手数料', amount = 300000},
        {label = '強盗未遂', amount = 300000},
        {label = '道路交通法違反', amount = 300000},
        {label = '銃刀法違反', amount = 400000},
        {label = '軽強盗罪', amount = 600000},
        {label = '準強盗罪', amount = 1200000},
        {label = '強盗罪', amount = 2400000},
        {label = '重強盗罪', amount = 4800000},
        {label = '殺人未遂', amount = 600000},
        {label = '誘拐罪', amount = 600000},
        {label = 'NPC殺人罪', amount = 600000},
        {label = '公務執行妨害', amount = 800000},
        {label = '殺人罪', amount = 1200000},
        {label = 'わいせつ罪', amount = 50000000},
        {label = '麻薬原料所持', amount = 2000000},
        {label = '麻薬所持1', amount = 4000000},
        {label = '麻薬所持2', amount = 6000000},
        {label = '麻薬所持3', amount = 8000000},
        {label = '麻薬精製現行犯', amount = 3000000},
        {label = '麻薬販売現行犯', amount = 4000000},
    },
    ['mechanic'] = {
        {label = '修理', amount = 200000},
        {label = '出張修理', amount = 600000},
    },
    ['speedfast'] = {
        {label = '修理', amount = 200000},
        {label = '出張修理', amount = 600000},
    },
    ['ambulance'] = {
        {label = '院内', amount = 200000},
        {label = '院外', amount = 500000},
        {label = '怪我治療', amount = 100000},
        {label = '山岳・海難', amount = 800000},
        {label = 'PD事件対応', amount = 150000},
    }
}

-- メッセージ設定
Config.Messages = {
    invoice_created = '請求書を作成しました',
    invoice_received = '新しい請求書を受け取りました',
    invoice_paid = '請求書の支払いが完了しました',
    invoice_cancelled = '請求書をキャンセルしました',
    not_enough_money = '所持金が不足しています',
    invalid_target = '無効な請求先です',
    no_permission = '権限がありません',
    insufficient_funds = '対象者の所持金が不足しているため強制執行できません',
    force_payment_success = '強制執行が完了しました',
    force_payment_failed = '強制執行に失敗しました'
}

return Config