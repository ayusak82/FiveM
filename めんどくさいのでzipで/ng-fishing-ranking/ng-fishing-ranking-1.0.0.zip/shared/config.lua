Config = {}

-- ランキング設定
Config.RankingLimit = 10 -- 表示するランキング数
Config.RefreshTime = 300 -- ランキング更新間隔（秒）

-- UI設定
Config.OpenCommand = 'fishranking' -- ランキングを開くコマンド
Config.AllowedJobs = nil -- 特定の職業のみ閲覧可能にする場合は設定する ('police', 'ambulance' など)

-- デバッグモード
Config.Debug = false